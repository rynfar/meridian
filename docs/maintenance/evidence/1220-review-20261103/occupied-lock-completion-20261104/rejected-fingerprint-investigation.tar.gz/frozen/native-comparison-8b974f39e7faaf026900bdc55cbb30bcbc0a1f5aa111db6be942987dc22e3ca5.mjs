import { createHash } from "node:crypto"
import { readFileSync } from "node:fs"
import { cpus, loadavg, platform, release } from "node:os"

const [baselinePath, fixedPath, manifestPath] = process.argv.slice(2)
const baseline = await import(baselinePath)
const fixed = await import(fixedPath)
const manifest = JSON.parse(readFileSync(manifestPath, "utf8"))
for (const entry of manifest.entries) {
  const content = readFileSync(entry.path)
  if (content.length !== entry.size || createHash("sha256").update(content).digest("hex") !== entry.sha256) throw Error("Corpus verification failed: " + entry.sourcePath)
}
console.log(JSON.stringify({kind:"environment", execPath:process.execPath, versions:process.versions, platform:platform(), release:release(), architecture:process.arch, cpu:cpus()[0]?.model, load:loadavg(), files:manifest.entries.length, bytes:manifest.entries.reduce((sum, entry) => sum + entry.size, 0)}))
let expectedDigest
function pass(label, mod, phase, pair) {
  const hash = createHash("sha256")
  const start = performance.now()
  const budget = mod.fingerprintBudget()
  let completed = 0
  try {
    for (const entry of manifest.entries) {
      budget.entry()
      hash.update(entry.sourcePath).update("\0")
      mod.hashFileInto(hash, entry.path, budget)
      completed++
    }
    const digest = hash.digest("hex")
    const elapsedMs = performance.now() - start
    if (expectedDigest !== undefined && expectedDigest !== digest) throw Error("Content digest changed")
    expectedDigest = digest
    console.log(JSON.stringify({kind:"pass", label, phase, pair, elapsedMs, completed, digest, ok:true, load:loadavg()}))
  } catch (error) {
    console.log(JSON.stringify({kind:"pass", label, phase, pair, elapsedMs:performance.now()-start, completed, ok:false, error:String(error), load:loadavg()}))
    throw error
  }
}
pass("baseline", baseline, "warmup", -1)
pass("fixed", fixed, "warmup", -1)
for (let pair = 0; pair < 6; pair++) {
  const order = pair % 2 ? [["fixed", fixed], ["baseline", baseline]] : [["baseline", baseline], ["fixed", fixed]]
  for (const [label, mod] of order) pass(label, mod, "measured", pair)
}
