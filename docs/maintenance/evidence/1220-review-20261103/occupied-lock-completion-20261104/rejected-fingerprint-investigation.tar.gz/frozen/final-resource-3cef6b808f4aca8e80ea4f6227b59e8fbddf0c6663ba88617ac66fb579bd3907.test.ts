import { afterEach, expect, spyOn, test } from "bun:test"
import { createHash } from "node:crypto"
import { appendFileSync, mkdtempSync, rmSync, writeFileSync } from "node:fs"
import { tmpdir } from "node:os"
import { join } from "node:path"
import { fingerprintBudget, hashFileInto } from "./final-buildFingerprint-a8c01473c5eba083d20b69bc90eb6908308a405b837afc2e7694af54b293b184.ts"

const roots: string[] = []
afterEach(() => { for (const root of roots.splice(0)) rmSync(root, { recursive: true, force: true }) })

function fixture(content: Buffer): string {
  const root = mkdtempSync(join(tmpdir(), "meridian-fingerprint-resource-"))
  roots.push(root)
  const path = join(root, "input")
  writeFileSync(path, content)
  return path
}

function allocationsDuring(run: () => void): number[] {
  const allocate = spyOn(Buffer, "allocUnsafe")
  try {
    run()
    return allocate.mock.calls.map(([size]) => size)
  } finally { allocate.mockRestore() }
}

test.each([0, 7, 4097, 64 * 1024 + 3])("hash scratch allocation is bounded by file size, with a nonzero floor (%i bytes)", size => {
  const content = Buffer.alloc(size, 0x61)
  const path = fixture(content)
  const hash = createHash("sha256")
  const budget = fingerprintBudget()
  const allocations = allocationsDuring(() => hashFileInto(hash, path, budget))
  expect(allocations).toEqual([Math.max(1, Math.min(size, 64 * 1024))])
  expect(hash.digest("hex")).toBe(createHash("sha256").update(content).digest("hex"))
})

test.each([0, 7])("a file growing after fstat is still hashed through EOF (%i initial bytes)", size => {
  const original = Buffer.alloc(size, 0x61)
  const appended = Buffer.alloc(128 * 1024, 0x62)
  const path = fixture(original)
  const hash = createHash("sha256")
  const budget = fingerprintBudget()
  let consumed = 0
  let reads = 0
  hashFileInto(hash, path, {
    ...budget,
    check: () => { budget.check(); reads++ },
    file: length => {
      budget.file(length)
      expect(length).toBe(size)
      appendFileSync(path, appended)
    },
    consume: length => { budget.consume(length); consumed += length },
  })
  expect(consumed).toBe(original.length + appended.length)
  // One check per read attempt, including EOF; growth costs at most one extra
  // initial small read before returning to 64KiB streaming.
  expect(reads).toBeLessThanOrEqual(Math.ceil(consumed / (64 * 1024)) + 2)
  expect(hash.digest("hex")).toBe(createHash("sha256").update(original).update(appended).digest("hex"))
})
