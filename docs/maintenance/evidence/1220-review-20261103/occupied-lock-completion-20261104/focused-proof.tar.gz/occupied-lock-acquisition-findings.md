# Occupied session-store lock acquisition: implementation and focused proof

## Scope and limits

- Worktree: `/Volumes/DevSSD/meridian/fix-occupied-lock-acquisition-20261103`.
- Branch: `fix/occupied-lock-acquisition-20261103`. Base/HEAD: `1e24a969cc8aba8c62ad3fcea87a4f3da69c6e52` (fresh `origin/main`). No commits, push or PR created. Parent owns integration into existing maintainer PR #1506 and combined final gates.
- Complete changed-file list: `src/proxy/sessionStore.ts` and new `src/__tests__/store-lock-acquisition.test.ts`.
- Production change: 14 added lines / 1 replaced line. Before durable candidate creation, an advisory `lstatSync` check detects any present path (including a dangling symlink). Only `ENOENT` means absent; other errors propagate through the existing acquire-error wrapper.
- Atomic initialized-file hard-link publication remains the authority after an absence observation. Concurrent arrivals still produce native `EEXIST` and cannot grant the lock.
- No changes to the 100 ms maintenance budget, stale threshold 0, default timeouts, strict age checks, incarnation/owner-death checks, recovery claims, release logic, SDK, dependencies, or public interfaces. No diagnostic instrumentation landed.
- **The old hosted timeout cause remains unresolved.** This corrects the independent, demonstrated cost of staging/fsyncing contenders for already-occupied paths. It does not establish that this cost caused the earlier hosted event, nor prove that event is resolved.

## Frozen custody

Source and test were copied to hash-named read-only files **before** any checks. Source hashes were verified unchanged after all checks. Baseline used a detached worktree at the same base, unchanged tracked production source and the exact identical new test.

- Manifest: `/Volumes/DevSSD/meridian/occupied-lock-acquisition-evidence-20261104/frozen-manifest-v1.json`.
- Complete unified patch: `/Volumes/DevSSD/meridian/occupied-lock-acquisition-evidence-20261104/implementation.5fd3d8d32f6f85e3c75445650fb4de3586cd05e7a58f21000330488b80e679a4.patch`.
- Patch SHA256: `5fd3d8d32f6f85e3c75445650fb4de3586cd05e7a58f21000330488b80e679a4`.
- Production SHA256: `525c4822eea86932bf3b5619508ccc6408ba49d162781057df5bc25f4b94f6c1`.
- Test SHA256: `932965b4158d7debc8cf8c204f01c7ba49826cc016d9a316b17e648d7b0db958`.
- Run/log hash receipt: `/Volumes/DevSSD/meridian/occupied-lock-acquisition-evidence-20261104/verification-v1.json`.
- Detached baseline worktree: `/Volumes/DevSSD/meridian/occupied-lock-baseline-20261104`. Its only added source artifact is the identical test; no production changes.

## Discriminating proof

The direct dead-owner case creates its lock through an actual child calling the unchanged `withLegacyStoreMaintenanceLock`, then self-`SIGKILL`s inside the lock callback. Bounded native `spawnSync` returns/reaps the child. The test checks no spawn error, empty stderr, null status and `SIGKILL`; parses the child's actual lock incarnation, verifies its PID and uses the native incarnation probe to prove death. It gives the existing lock an old mtime explicitly rather than waiting for timestamp resolution.

A logical clock charges **synthetic 101 ms** only after a delegated, real fsync of a new store-lock candidate while the old lock remains present. This is an injected policy discriminator, **not measured filesystem latency or evidence about the original host**. File creation/fsync/link and process-incarnation death checks retain native implementations.

- Original production code: actual candidate counts are `opened=1, synced=1, occupiedSyncs=1`; the required `occupiedSyncs=0` assertion fails. By code path, the synthetic charge expires the unchanged 100 ms budget before stale recovery.
- Corrected production code: `opened=1, synced=1, occupiedSyncs=0`; both delegated native dead-owner checks return true for the child PID; callback enters with a fresh canonical current-process lock, mode 0600; logical elapsed remains 0; release/recovery leaves no artifacts.
- The normal unoccupied candidate still incurs real durable initialization. It was not made non-durable or bypassed to make the test pass.

Other exact controls:

1. Current live owner, empty token, malformed JSON and real migration-barrier bytes remain present and block admission without opening/fsyncing a contender. The live-owner check still delegates to the actual incarnation decision.
2. A dangling symlink remains occupied and is preserved (POSIX-only fixture; skipped on Windows because symlink privileges are not assumed).
3. A competing migration barrier is installed immediately before the real native hard link. Native `EEXIST` is observed exactly once, admission times out, callback does not enter, and competitor bytes remain unchanged. This control **passes on both baseline and corrected code**.
4. A non-ENOENT `lstat` error preserves the exact error as `cause`, with no staging.

The deterministic clocks do not add sleeps or expand production budgets. Every spy is restored in `finally`.

## Executed checks

Native project environment: Bun 1.3.14 (`0d9b296a`), Node v22.22.3, npm 10.9.8 on Darwin arm64. Existing dependencies were reused by a `node_modules` symlink; nothing installed. Test commands used `BOOKKEEPING_TEST_SQLITE_LIBRARY=/opt/homebrew/opt/sqlite/lib/libsqlite3.3.53.4.dylib`. No models, SDK generations, credential reads, live clients, full suite or application build were run.

| Check | Result | Evidence |
| --- | --- | --- |
| Corrected `bun test src/__tests__/store-lock-acquisition.test.ts` | 8 pass, 0 fail, 51 expectations | `/Volumes/DevSSD/meridian/occupied-lock-acquisition-evidence-20261104/focused-fixed-v1.log` |
| Same test against original base production source | **1 pass / 7 fail (expected)**; dead-owner fs-operation assertion red; atomic-race control green | `/Volumes/DevSSD/meridian/occupied-lock-acquisition-evidence-20261104/focused-baseline-v1.log` |
| `npm run typecheck` | exit 0 | `/Volumes/DevSSD/meridian/occupied-lock-acquisition-evidence-20261104/typecheck-v1.log` |
| Existing `bun test src/__tests__/proxy-session-store-locking.test.ts` | 7 pass, 0 fail, 135 expectations; real concurrent writers, stale takeover, dead-claim recovery, live/remote fail-closed, corrupt-store behavior, private atomic write | `/Volumes/DevSSD/meridian/occupied-lock-acquisition-evidence-20261104/adjacent-locking-v1.log` |
| Existing crash fixture, `--test-name-pattern 'SIGKILL migration 2/1 PREPARED'` | 1 pass, 201 filtered out, 24 expectations | `/Volumes/DevSSD/meridian/occupied-lock-acquisition-evidence-20261104/prepared-resume-v1.log` |
| `git diff --check` and final source/test hash equality | pass | Manifest + verification receipt |

The single local PREPARED pass is adjacent regression coverage only. It is not a reproduction or explanation of the old hosted timeout and does not waive its failed required CI gate. Full `npm test`, build, combined-head required CI, review, and any affected-flow acceptance remain the parent's responsibility.

## Assumptions / constants

- Assumed the narrow independent occupied-path cost improvement is authorized; do not infer historical causality or merge authorization from these local checks.
- `lstat` absence is only an optimization hint. Hard-link CAS handles TOCTOU exactly as before.
- Production constants changed: **none**. Test-only 101 ms is a synthetic occupied-candidate cost; test-only mtime is one second old to satisfy the existing strict age check without sleeping.
