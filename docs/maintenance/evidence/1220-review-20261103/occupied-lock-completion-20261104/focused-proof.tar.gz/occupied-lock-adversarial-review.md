# Occupied session-store lock: independent review

## Verdict and scope

**Approved for integration of frozen V1; no material source blocker found. Not merge/release approval.** Reviewed the complete two-file patch against `origin/main` / base `1e24a969cc8aba8c62ad3fcea87a4f3da69c6e52`, baseline/final source bytes, five hashed local check logs, and the parent's packaged-CLI addition. This reviewer only read/compared files and wrote this report: no programs, tests, network, model calls or source edits.

Patch SHA256: `5fd3d8d32f6f85e3c75445650fb4de3586cd05e7a58f21000330488b80e679a4`. Manifest and receipts: `/Volumes/DevSSD/meridian/occupied-lock-acquisition-evidence-20261104/{frozen-manifest-v1.json,verification-v1.json}`. Both hash-named frozen sources and patch are mode 0444 and match source/hash data. Regenerated diff exactly matches the captured base plus the new test; baseline worktree has the same base production bytes and identical test. Compared source/scripts/bin/CI/package/dependency boundaries against that baseline: only `sessionStore.ts` differs (the test is copied to both trees).

## Concrete findings

- **Product fit:** the original acquisition synchronously creates/writes/fsyncs a contender even when the canonical lock is already occupied. V1 avoids that independent unnecessary event-loop/storage cost. It does not identify the cause of the earlier hosted timeout; that cause remains **UNRESOLVED**. The prior passing diagnostic is not proof of a fix.
- **Authority/races:** `lstat` is only a hint. Only ENOENT permits staging, and the unchanged initialized-file hard link remains the sole acquisition authority. An absent→occupied race still receives native EEXIST and cannot enter; its control passes on both versions. For occupied→absent, unchanged stale inspection returns true on ENOENT and retries within the existing budget; this path was inspected, not directly injected in the new test. No dead/age/incarnation/claim/identity/release rule changes. No lock is deleted by the new helper.
- **Negative boundaries:** live, empty, malformed and migration-barrier bytes remain fenced; dangling symlinks count as occupied rather than absent. Non-ENOENT inspection errors fail closed through the existing acquire wrapper with the exact cause. No new recovery authority, caches, public contracts, dependencies or diagnostic observer code.
- **Budget:** constants changed **none**. The maintenance 100 ms / stale 0 call and both deadline checks remain byte-identical. The synthetic 101 ms test charge distinguishes wasted occupied fsync work; it is not measured latency or historical-causality evidence. Existing native crash and locking test sources are unchanged.

## Bun mock isolation: final decision

**Yes: run this real native lock/death proof in its own fresh Bun process, as the parent selected for the final combined head.** The new file uses process-global fs/performance/incarnation spies; a clean process gives its native-evidence claims a clear boundary from the large SDK-mocked group. My initial source audit found no demonstrated existing cross-file leak: this test is synchronous/non-concurrent, installs no module-scope mocks, captures native implementations before scoped spies, and restores every installed spy in `finally`; existing `store-mutation-baseline` openSync spies are scoped too. The profile-expiry/login native mocks inspected are worker-only branches, so those files alone do not prove a leak into group 0. Nevertheless, explicit isolation is a small, reasonable evidence-strengthening choice, not a claim of an observed contamination.

Read the final combined package test command: group 0 adds `--path-ignore-patterns '**/*store-lock-acquisition*'`, and `bun test --timeout 30000 src/__tests__/store-lock-acquisition.test.ts` runs immediately after isolated `integration-concurrent`. The command has 28 groups. The test is not omitted, no assertion is relaxed, and the 30-second runner bound is unchanged. This removes the dependency on large-group mock state while retaining final full-suite and CI obligations.

## Evidence inspected

All five log hashes match `verification-v1.json`; recorded native exits agree with their logs. Darwin arm64, Bun 1.3.14, Node 22.22.3; local SQLite library override is documented in the worker findings.

- Final focused: **8 pass / 0 fail**, 51 expectations, exit 0.
- Identical test against unchanged base: **1 pass / 7 expected fail**, exit 1. Dead-owner failure reports an actual occupied contender fsync; native atomic-race refusal remains green. Other red checks discriminate wasted staging, not merely elapsed time.
- Real child self-SIGKILL is joined by bounded spawnSync; status/signal/PID and native incarnation-death probe are checked. Final then requires both delegated death checks, one unoccupied durable contender, callback ownership/mode and no residue.
- Typecheck: exit 0. Existing real concurrent/stale/dead-claim/live/remote/corrupt-store locking suite: **7 pass**, 135 expectations. Existing `SIGKILL migration 2/1 PREPARED`: **1 pass**, 24 expectations (201 filtered). That single local pass is adjacent coverage only.

## Packaged CLI escrow and remaining gates

Read the final 15-line addition in `/Volumes/DevSSD/meridian/fix-test-isolation-20261103/scripts/e2e-session-bookkeeping-packaged.mjs` (whole-file SHA256: `441639d6ece368ab0612d36f522c52a534bd170ad490ed7d8c313314eed00e73`). It invokes the independently installed candidate's actual Node CLI, requests the existing PREPARED self-SIGKILL seam, checks native error/status/signal, persisted journal phase PREPARED and owner PID, resumes to ready, exports unchanged empty JSON and checks lock removal. The explicit phase witness requested in review is now present. It neither injects a clock nor changes production deadlines; the 30-second crash-process timeout is unchanged from existing packaged crash cases. It is durable affected-storage CLI escrow, not a model/client E2E or original-timeout reproduction.

Final combined integration head reported by parent: `02554a0a748f695b79982da071145f83c402415c`; occupancy source/test bytes still match frozen V1. Parent still owns the complete combined diff review, full `npm test`, typecheck/build, freshly built/installed packaged CLI execution and final-head required CI, including `test`. Prior fixture fixes are not independently reapproved by this narrowly scoped report; no contributor commits or diagnostic observer code are authorized to land here. Preserve concise before/after proof and unresolved historical cause in the PR/handoff. No gate waiver, timeout increase, merge or release clearance is implied.
