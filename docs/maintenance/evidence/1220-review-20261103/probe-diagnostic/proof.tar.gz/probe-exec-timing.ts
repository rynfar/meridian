import { spawn, execFile } from 'node:child_process'
import { mkdtempSync, writeFileSync, readFileSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
const fixtureBody = readFileSync("/Volumes/DevSSD/meridian/evidence/review-1220-20261103/probe-exec-diagnostic/probe.cjs", 'utf8')
const nativeNode = '/Users/rynfar/.local/bin/node'
const results: unknown[] = []
async function run(label:string, direct:boolean, reused?:string):Promise<string> {
 const root = reused ?? mkdtempSync(join(tmpdir(), 'agy-probe-diag-'))
 const executable = join(root, 'probe.cjs')
 if (!reused) writeFileSync(executable, fixtureBody, {mode:0o755})
 const started=performance.now(), observations:unknown[]=[]
 const child=spawn(direct?nativeNode:executable,direct?[executable,'models']:['models'],{env:{...process.env,AG_PROBE_ROOT:root,AG_PROBE_MODE:'success'},stdio:['pipe','pipe','pipe'],detached:true})
 let bytes=0
 child.stdout.on('data',b=>{bytes+=b.length;observations.push({kind:'stdout',at:performance.now()-started,bytes:b.length})})
 child.stderr.on('data',b=>{bytes+=b.length;observations.push({kind:'stderr',at:performance.now()-started,bytes:b.length})})
 child.stdin.end()
 child.on('spawn',()=>observations.push({kind:'spawn',at:performance.now()-started,pid:child.pid}))
 child.on('error',e=>observations.push({kind:'error',at:performance.now()-started,message:e.message}))
 function signal(sig:NodeJS.Signals){try{if(child.pid)process.kill(-child.pid,sig)}catch{}}
 const snapshots=[100,500,900].map(ms=>setTimeout(()=>{
  execFile('/bin/ps',['-p',String(child.pid),'-o','pid=,etime=,state=,comm=,args='],{timeout:500,maxBuffer:4096},(_e,out)=>observations.push({kind:'process',at:performance.now()-started,out:out.trim(),calls:existsSync(join(root,'calls')),count:existsSync(join(root,'count'))}))
 },ms))
 let kill:ReturnType<typeof setTimeout>|undefined
 const timeout=setTimeout(()=>{observations.push({kind:'timeout',at:performance.now()-started});signal('SIGTERM');kill=setTimeout(()=>signal('SIGKILL'),50)},1000)
 const outer=setTimeout(()=>{signal('SIGKILL');console.error('unjoined diagnostic child');process.exitCode=2},3000)
 await new Promise<void>(resolve=>child.once('close',(code,sig)=>{
  clearTimeout(timeout);clearTimeout(kill);clearTimeout(outer);for(const t of snapshots)clearTimeout(t)
  results.push({label,direct,root,pid:child.pid,elapsed:performance.now()-started,exit:code,signal:sig,bytes,calls:existsSync(join(root,'calls'))?readFileSync(join(root,'calls'),'utf8'):null,count:existsSync(join(root,'count'))?readFileSync(join(root,'count'),'utf8'):null,observations});resolve()
 }))
 return root
}
const first=await run('fresh shebang',false)
await run('same file direct Node',true,first)
await run('same file shebang again',false,first)
await run('fresh direct Node',true)
await run('second fresh shebang',false)
console.log(JSON.stringify({runtime:{bun:Bun.version,node:nativeNode,platform:process.platform,arch:process.arch},results},null,2))
