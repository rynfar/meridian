import { mkdtempSync, rmSync, writeFileSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
const repo = process.argv[2];
const { setSessionStoreDir } = await import(pathToFileURL(join(repo, "src/proxy/sessionStore.ts")).href);
const { storeSession, evictSession, lookupSession, clearSessionCache } = await import(pathToFileURL(join(repo, "src/proxy/session/cache.ts")).href);
const dir = mkdtempSync(join(tmpdir(), "meridian-review-1220-evict-"));
setSessionStoreDir(dir);
try {
  await clearSessionCache();
  for (const keyed of [true, false]) {
    await clearSessionCache();
    const sessionId = keyed ? "review-evict-session" : undefined;
    const messages = [{role: "user", content: "hello"}];
    const continuation = [...messages, {role: "user", content: "next"}];
    const cwd = "/tmp/meridian-review-1220";
    await storeSession(sessionId, messages, "review-sdk-session", cwd);
    const pending = evictSession(sessionId, cwd, messages);
    const overlapping = lookupSession(sessionId, continuation, cwd);
    const evicted = await pending;
    const durableBytes = readFileSync(join(dir, "sessions.json"), "utf8");
    const raw = JSON.parse(durableBytes);
    writeFileSync(join(dir, "sessions.json"), "corrupt fixture");
    const afterError = lookupSession(sessionId, continuation, cwd);
    console.log(JSON.stringify({keyed, evicted, rawKeys: Object.keys(raw), overlapping: overlapping.type, afterError: afterError.type, reason: afterError.reason, resumed: afterError.session?.claudeSessionId}));
    writeFileSync(join(dir, "sessions.json"), durableBytes);
  }
} finally {
  await clearSessionCache();
  setSessionStoreDir(null);
  rmSync(dir, {recursive: true, force: true});
}
