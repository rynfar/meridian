# Adversarial review: source-recovery deadline fixture

## Verdict and custody

**No material source finding in the reviewed candidate.** The replacement tests shared-deadline accounting deterministically while retaining real native child timeouts and joining. It does not establish the original red's exact cause or a production behavior change.

- Frozen file: `/Volumes/DevSSD/meridian/fix-source-recovery-fixture-20261103/src/__tests__/build-source-recovery.test.ts`.
- SHA256 verified: `f4b9e510928500b7567f9d8b37354e0cba82337ec16d5146e2e1a4933e4c8bfd`.
- Checkout HEAD inspected: `697f9482c23865e9d9a02095e35d79b0922047a7`. Working diff contains only that test file, +64/-11. Read-only `git diff --check` passed.
- `src/proxy/buildSnapshot.ts` is byte-identical to the prior inspected source, SHA256 `daad6bf46cd967f8af79ff377745d8686f2793875b08926e980498bacac36f2c`.
- I ran no tests, builds, negative-control helpers, live calls, or network commands, and edited no source. The authorized worker owns focused/typecheck and two shadow negatives. This report makes no claim that those checks have passed. Parent owns final combined-PR integration, full-suite, build, and final-head CI gates.

## Concrete checks

1. **Product fit and boundaries:** The old test mixed 1200ms mandatory synthetic sleeps with 750ms optional native timeouts, leaving only 50ms for startup before exhausting the real 2000ms budget. The replacement separates arithmetic from native scheduling. No production injection seam, API, module dependency, packaging, permission, source deadline, or kill behavior changes. The test-only `fakeGit()` return now exposes its own script path; other callers are unaffected.
2. **Exact routing scope (`:159–165`):** The wrapper matches command `git`, `-C`, this exact fixture root, and this process's exact fixture PATH. Only that isolated child is patched. The fixed script comes from the fake Git file at the first directory of that PATH, not from arbitrary production input. Unmatched calls forward original command/args/options to the saved native function. The separate shell fixture is not routed through Node.
3. **Node argv and options (`:165`):** Native invocation is resolved Node plus `[script, ...originalArgs]`; `-C, root` stay present. Consequently the generated script's existing `process.argv.slice(4)` still yields Git arguments. The exact original `options` object is forwarded, not reconstructed or extended. Real timeouts, encoding, buffer cap, stdio, and SIGKILL remain production values.
4. **ESM binding (`:156–177`):** The child changes the built-in's default object, calls `syncBuiltinESMExports()`, then dynamically imports the bundle. This order supplies the wrapper to the bundle's named `spawnSync` import. The hook cannot affect shared Bun tests because it exists only inside this one stock-Node probe process. No restore is required after the process exits.
5. **Clock separation (`:166–178`):** Only the source-visible `performance.now` value is controlled. `nativeSpawnSync` still receives numeric production timeouts and enforces them natively; a logical increment neither substitutes a fake result nor shortens native waiting. The pre-bound `realNow` measures actual safety-bound elapsed time. Mandatory responses are real subprocess output and must succeed; failures are explicitly rejected with recorded native details.
6. **Meaningful regression discrimination (`:194–216`):** New logical mandatory charges 800+800 leave 400ms of the original 2000ms policy budget. Actual optional children retain the 600ms delay, receive real 250ms then 150ms SIGKILL timeouts, and exhaust logical time exactly. Assertions require timeout sequence `[2000,1200,250,150]`, exact command order root/SHA/branch/status, actual root/SHA stdout, no config spawn, no branch/dirty claim, successful mandatory results, and native optional `ETIMEDOUT`/SIGKILL results. A per-command fresh deadline or failure to reduce the last timeout fails these assertions. Shadow negative execution remains the worker's evidence obligation, not my source-review claim.
7. **Direct-child custody (`:167–192`):** Native return PIDs are recorded independently of fixture JavaScript entry. Each must be positive and dead before the test proceeds. Thus an optional process killed before appending to `calls.jsonl` is still covered. The existing log-based joined check remains supplementary and is safe to read because both successful mandatory scripts append before producing required stdout. Script processes launch no descendants.
8. **Separate controls preserved:** Everything from `an exhausted root deadline does not start subsequent Git commands` through the end of the file is byte-identical to the pre-change version, as are the TERM-resistant shell helper and all other earlier cases. Their real elapsed limits, readiness guard, default-SIGTERM contrast, SIGKILL checks, PIDs, exhausted-root no-subsequent-command assertion, and fingerprint timeout remain unchanged.

## Claims that must stay limited

- Deterministic here means **deadline-policy arithmetic and supplied timeout sequence**, not a real-time guarantee under arbitrary host starvation. Actual mandatory subprocess failure or the retained 2500ms safety bound can still make the test red; those failures must not be waived.
- The old 600ms mandatory sleeps are removed; **new 800ms logical charges** replace their accounting role. Optional 600ms timers and all native timeout upper bounds remain. This is not merely sleeping less to obtain green.
- Explicit Node bypasses executable-shebang routing for this test. Neither the old error log nor this fixture proves that a shebang stall caused the original source-recovery red. Preserve that original red and its unavailable causal detail.
- This is test infrastructure only. It does not prove #1220 product acceptance, actual client/model E2E, a production fix, or release readiness. No live call is appropriate for this scoped test-only repair.
- Review is for the exact frozen test hash above, not an unseen combined PR head. After integration, verify the file hash and full intended diff; required final-head CI still applies. A later green rerun does not erase the earlier red.

## Remaining gates

Parent should retain the focused/typecheck and two shadow-negative logs with this exact source hash, integrate only the authorized test diff, and run normal final gates under its ownership. Publish this concise review and the prior red/after evidence in the durable PR record rather than relying on local paths alone. No source correction is requested by this review.
