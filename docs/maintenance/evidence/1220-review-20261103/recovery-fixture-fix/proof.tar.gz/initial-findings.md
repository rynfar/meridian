# Source-recovery fixture findings (read-only)

## Scope and conclusion

Inspected `/Volumes/DevSSD/meridian/fix-probe-launcher-20261103` at the parent's reported source `e1413322c891384f59651774fe2fb14b724b832c`. No source edits, tests, builds, subprocess diagnostics, network requests, or model calls were made. This report is the only file created. No constants were changed.

**Recommendation: replace the single accumulated-wall-time fixture with deterministic deadline propagation inside its isolated stock-Node probe.** Use a child-local controllable `performance.now` and an exact-fixture native `spawnSync` wrapper. Keep actual mandatory root and SHA subprocesses, actual optional subprocesses, native SIGKILL/timeouts, and PID joining. There is no evidence justifying a production change, deadline increase, or acceptance-gate waiver.

The observed red remains evidence. A later green run does not erase it. The current record cannot establish whether its immediate cause was shebang launch delay, ordinary scheduling/startup delay, or another subprocess failure.

## Concrete evidence

- Log: `/Volumes/DevSSD/meridian/evidence/fix-probe-launcher-20261103/full-npm-test.log`, lines 3677–3704. `probe()` throws after `sourceIdentity()` raises `BuildProvenanceError("git")`; case duration is 2218.88ms. The intended optional-fact assertions did not run. The surviving log does not identify which mandatory subprocess failed or its native error/status. Do not describe this as a demonstrated optional-timeout bug.
- Source: `src/proxy/buildSnapshot.ts:13–21`. `gitOutput()` uses real `spawnSync("git", ["-C", root, ...args], ...)`, rejects native errors/nonzero exit, and uses `killSignal: "SIGKILL"`.
- Source: `src/proxy/buildSnapshot.ts:28–54`. One deadline is `performance.now() + 2000`; canonical root and SHA are mandatory. Each optional command gets `min(250, remaining)`; exhausted optional calls are caught and omitted. This behavior fits the observed failure when mandatory recovery itself cannot complete.
- Test: `src/__tests__/build-source-recovery.test.ts:50–58`. `fakeGit()` writes an executable with an absolute Node shebang. Its call record is appended only after fixture JavaScript begins. An absent record cannot distinguish no launch from a pre-JavaScript stall. The temporary failed bundle no longer exists.
- Test: `src/__tests__/build-source-recovery.test.ts:148–165`. Every synthetic command waits 600ms, including root and SHA. Mandatory waits consume 1200ms before startup overhead. Ideal optional timeouts cost 750ms, totaling **1950ms**, not deterministic exhaustion of 2000ms. Whether the remaining deadline truncates a command depends on overhead. The test conflates budget propagation with executable startup/scheduling.
- Separate native controls remain in this same file: exhausted-root case at 166–177; real TERM-resistant child timeout and joined PID control at 178–202; fingerprint native timeout at 203–214. These must stay unchanged.
- Existing explicit-Node pattern: `src/__tests__/antigravity-probe.test.ts:10–29` routes registered scripts only, forwarding all options; its invalid-shebang control is at 79–87. An absolute shebang is not equivalent to `spawnSync(node, [script, ...args], options)`.

Read source SHA256: `daad6bf46cd967f8af79ff377745d8686f2793875b08926e980498bacac36f2c`.
Read test SHA256: `d845b8d51c775cc8cfa3702bbd14a0b964afb3676d3443bc3bdc6ea869248581`.

## Smallest robust replacement design

Change only the slow-optional test and the minimum test-only helper plumbing it needs. No production injection seams or source-budget changes.

1. Run the case in its existing isolated stock-Node `probe()` process. Before dynamic-importing the bundled snapshot module, install a process-local `node:child_process` `spawnSync` wrapper, then call `syncBuiltinESMExports()` so the bundled named import uses that wrapper. Retain the original native function.
2. Match only this test's synthetic Git invocation (`"git"`, `-C`, exact fixture root, and exact registered fake-script path). Route it to the resolved Node executable with `[fakeScript, ...originalArgs]`. Forward the **same options object** to native `spawnSync`; unrelated calls go through unchanged. Do not route the POSIX TERM-resistant shell control through Node.
3. Mandatory root and SHA script branches respond immediately with the actual fixture root and SHA. They remain real launched/joined children. Removing the old arbitrary 600ms mandatory waits is not the fix by itself: replace their timing role with explicit logical clock charges, and assert those charges through the exact timeout sequence below.
4. After importing the module, install an own, child-local `performance.now` implementation backed by a logical `now = 0`. Do not change the native child-process timeout clock. No global Bun mock or cross-test state is needed because the outer probe exits.
5. The wrapper performs each real native spawn, records arguments, the supplied timeout, returned PID/status/signal/error, then advances logical time according to the scenario. Fail if either mandatory result fails. Root advances logical time by 800ms; SHA advances by 800ms. These are explicit **test clock inputs**, not changed production deadlines or real sleeps.
6. Keep the optional script branches slow (the existing 600ms timer suffices). Branch gets a real native 250ms SIGKILL timeout, after which the wrapper advances logical time by 250ms. Status then gets a real native **150ms** SIGKILL timeout, after which the wrapper advances logical time by 150ms. The shared logical deadline is now exactly exhausted; the remote/config command must never reach the native wrapper.
7. Assert exact native call order `root, SHA, branch, status`; exact timeout sequence **[2000, 1200, 250, 150]**; real SHA returned; branch and dirty omitted; no config call; native optional timeout errors/killed results; and every returned child PID is dead. Record the wrapper's PID as well as any JavaScript-entry log so a child killed before JavaScript starts still has custody evidence. Retain the existing real elapsed upper bound as a native-process safety check, not as proof of the shared-deadline arithmetic.

This deterministically rejects a fresh per-command recovery deadline, failure to reduce the final optional timeout, or starting commands after exhaustion. It still requires real mandatory root/SHA output and real native optional process timeouts. It does not treat synthetic clock movement as evidence of a real-time scheduling guarantee. An optional script killed before JavaScript starts is a legitimate native timeout, not a reason to weaken PID cleanup checks.

Keep the separate exhausted-root, TERM-resistant default-SIGTERM comparison, SIGKILL, and fingerprint controls unchanged. No deadline/timeout upper bounds are increased and no negative controls are removed. Explicit Node removes the specific executable-shebang path; it does not promise immunity to arbitrary host starvation. If a native mandatory call still fails, preserve its diagnostics and keep the gate red.

## Discrimination and bounded next action

- **Actionable fixture repair:** yes, the deadline-propagation scenario above is deterministic without production seams. It fixes the test's conflation of policy accounting and startup overhead, rather than buying time.
- **Production bug:** not established. The production code rejects a mandatory command that cannot finish within its remaining real budget, which is consistent with its stated contract.
- **Missing evidence:** the exact native failure cause in the original red is unavailable. Do not label it a proven shebang stall or claim the replacement proves that cause.

After the parent suite has stopped and the root chooses this repair: implement only the test-local replacement, review/freeze the final helper/source hash, and run one targeted `bun test src/__tests__/build-source-recovery.test.ts` through this checkout's normal environment. Preserve exact native trace/timeout sequence and the original red durably. No repeated diagnostic loop is needed. Run typecheck and normal final full-suite/build gates only under the parent's ownership. This recommendation does not authorize any #1220 production change or relax its evidence gates.
