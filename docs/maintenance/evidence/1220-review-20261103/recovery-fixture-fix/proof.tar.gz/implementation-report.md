# Source-recovery fixture implementation

## Frozen source and scope

- Checkout: `/Volumes/DevSSD/meridian/fix-source-recovery-fixture-20261103`
- Branch/base: `test/source-recovery-fixture-20261103`, `697f9482c23865e9d9a02095e35d79b0922047a7`
- Only changed tracked file: `src/__tests__/build-source-recovery.test.ts`
- SHA256: `f4b9e510928500b7567f9d8b37354e0cba82337ec16d5146e2e1a4933e4c8bfd`
- Read-only source escrow: `/Volumes/DevSSD/meridian/evidence/source-recovery-fixture-20261103/build-source-recovery.f4b9e510928500b7567f9d8b37354e0cba82337ec16d5146e2e1a4933e4c8bfd.test.ts`
- Patch: `/Volumes/DevSSD/meridian/evidence/source-recovery-fixture-20261103/source-recovery-fixture.patch`
- Findings: `/Volumes/DevSSD/meridian/source-recovery-fixture-findings.md`

The frozen source is ready for the authorized single focused-file run and typecheck. No tests or builds have run in this checkout as of this freeze. No production, launcher, user, or contributor source was edited. No commits, network, live calls, or credential operations were performed.

## Choices and assumptions

- The one slow-optional case uses a process-local native `spawnSync` wrapper installed before the dynamic module import; `syncBuiltinESMExports()` propagates it to bundled named imports.
- Only `git -C <exact fixture root>` with the exact fixture PATH is routed to the registered fake script using the resolved stock Node executable. Unrelated calls forward unchanged. The same native options object is forwarded.
- Mandatory root and actual fixture SHA output are immediate real-child outputs. Child-local logical clock charges are 800ms each. Optional children still wait 600ms and receive real native SIGKILL timeouts of 250ms then 150ms. These are test clock inputs, not changed production constants or real sleeps.
- Exact native timeout sequence `[2000,1200,250,150]` and exact four-command order assert the shared budget and absence of a config command. Native PID/status/signal/error/stdout/stderr and clock charges remain in the trace even if a child dies before entering JavaScript. Every returned PID must be dead.
- The unchanged 2500ms real elapsed safety bound is not used as proof of deadline arithmetic. Root-exhaustion, TERM-resistant default-SIGTERM/SIGKILL, and fingerprint controls are byte-identical to their originals.
- `fakeGit` exposes its existing exact script path; other cases do not use the extra field.
- POSIX qualification and all production deadlines, test deadlines, waits, and dependency versions are unchanged except removal of this case's old mandatory 600ms waits. The optional wait remains 600ms. The new 800ms/800ms charges are explicit fixture inputs.
- The ignored `node_modules` symlink points to the authorized shared `/Volumes/DevSSD/meridian/review-1220-20261103/node_modules`.

## Pre-freeze self-review

Compared the full before/after source: only the single case and one return field in its existing fakeGit helper changed. The native controls after the case are unchanged. `git diff --check` passed. Reviewed wrapper matching, same-object options forwarding, native result custody before clock charging, failure diagnostics for mandatory results, and dead-PID checks independently of JavaScript-entry logs. No production seam or canned subprocess result was introduced.

## Validation

- Focused file: `cd /Volumes/DevSSD/meridian/fix-source-recovery-fixture-20261103 && bun test src/__tests__/build-source-recovery.test.ts > /Volumes/DevSSD/meridian/evidence/source-recovery-fixture-20261103/focused-file.log 2>&1`; exit 0, 13.65s, 10 pass / 0 fail / 75 assertions. Log: `/Volumes/DevSSD/meridian/evidence/source-recovery-fixture-20261103/focused-file.log`.
- Typecheck: `cd /Volumes/DevSSD/meridian/fix-source-recovery-fixture-20261103 && npm run typecheck > /Volumes/DevSSD/meridian/evidence/source-recovery-fixture-20261103/typecheck.log 2>&1`; exit 0, 15.99s. Log: `/Volumes/DevSSD/meridian/evidence/source-recovery-fixture-20261103/typecheck.log`.
- Native shared-budget trace: exactly `[2000,1200,250,150]`. The two mandatory children returned status 0 and the actual root/SHA. The two optional children returned ETIMEDOUT / SIGKILL / null status. All four native PIDs were dead. Real elapsed: 485.49625ms; logical elapsed: 2000ms. Root-exhaustion, TERM-resistant default-SIGTERM comparison/SIGKILL, and fingerprint controls passed unchanged.
- Both corrected shadow-source negative controls ran only the named slow-optional test and failed at the exact timeout-sequence assertion. Both shadows contain read-only regular copies of both build entrypoints; the unchanged runtime entrypoint SHA256 is `53b4b8bb3a6183f5b7c0993a64cb895bbc5c0762a8fa1bc099b3779665c8ba4e`. Real checkout production files were not edited.
  - Fresh-per-command recovery budget: replace `const remaining = Math.floor(deadline - performance.now())` with `const remaining = 2000`. Shadow snapshot SHA256 `ab5cf859fd97b1553a52aea1b331a704690ea0e38b53608710bf3c95106d4f44`. Exit 1, 1.35s. Observed native timeouts `[2000,2000,250,250,250]`, logical elapsed 2350ms, with a config command. All native PIDs were dead. Log: `/Volumes/DevSSD/meridian/evidence/source-recovery-fixture-20261103/negative-fresh-per-command-budget-corrected.log`.
  - Spawn after exhaustion: replace the exhausted-budget throw with `return gitOutput(root, args, Math.min(maximum, 250))`. Shadow snapshot SHA256 `ab1f36fa7559d4dee462475745427bb3ee7d8d895f91be12865489a67c1866b5`. Exit 1, 1.03s. Observed native timeouts `[2000,1200,250,150,250]`, logical elapsed 2250ms, with a config command after logical 2000ms. All native PIDs were dead. Log: `/Volumes/DevSSD/meridian/evidence/source-recovery-fixture-20261103/negative-spawn-after-exhaustion.log`.
- The earlier invalid shadow attempt is preserved separately and is **not** discrimination evidence: Bun rejected divergent resolved entrypoint roots before the case ran. Log: `/Volumes/DevSSD/meridian/evidence/source-recovery-fixture-20261103/negative-fresh-per-command-budget-invalid-entrypoint-roots.log`. Record: `/Volumes/DevSSD/meridian/evidence/source-recovery-fixture-20261103/invalid-shadow-attempt.json`. The parent explicitly authorized its one corrected replacement; there were no other reruns.
- Machine-readable custody, exact commands, mutations, full native traces, hashes, durations, and log paths: `/Volumes/DevSSD/meridian/evidence/source-recovery-fixture-20261103/validation-custody.json`.
- Final source SHA256 remains `f4b9e510928500b7567f9d8b37354e0cba82337ec16d5146e2e1a4933e4c8bfd`. No source edits after freeze. Final `git diff --check` passed; final `git status --short` contains only the allowed test file.

The parent retains the original full-suite red as independent evidence; this replacement does not establish its exact native failure cause. No full-suite/build run was performed by this child; the parent owns those final gates. No production acceptance gates were relaxed.
