import assert from 'node:assert/strict';
import fsPromises from 'node:fs/promises';
import {mkdtempSync,rmSync,writeFileSync,mkdirSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {once} from 'node:events';
import {randomUUID} from 'node:crypto';
import {observePublishedGate} from './gate-observer-75af2733bc17.mjs';
const root=mkdtempSync(join(tmpdir(),'meridian-gate-observer-control-'));
const observer=observePublishedGate(root);let gate;
const quote=value=>"'"+value.replaceAll("'",`'"'"'`)+"'";
const publish=async(text,directory=root)=>{
 const path=join(directory,process.pid+'-'+randomUUID()+'.gate');
 const temporary=path+'.tmp-'+process.pid+'-'+randomUUID();
 writeFileSync(temporary,text);assert.equal(await fsPromises.rename(temporary,path),undefined);
};
try{
 const {createSdkProcessGate}=await import('./sdk-process-gate-offline.mjs');
 gate=await createSdkProcessGate(root,async()=>undefined);
 const child=gate.spawnClaudeCodeProcess({command:process.execPath,args:['-e',String.raw`process.stdout.write("owned\n")`],env:{PATH:process.env.PATH,ANTHROPIC_DEFAULT_OPUS_MODEL:'claude-opus-5-5',CLAUDE_CODE_DISABLE_REFUSAL_FALLBACK:'1',PRIVATE_TEST_SECRET:'NEVER_RETAIN_ME'},signal:new AbortController().signal});
 let output='';child.stdout.on('data',chunk=>{output+=chunk;});await once(child,'close');
 assert.equal(await gate.closeAndJoin(),true);gate=undefined;
 assert.equal(output,'owned\n');assert.deepEqual(observer.errors,[]);
 assert.deepEqual(observer.rows,[{explicitOpusPin:'claude-opus-5-5',refusalFallbackDisabled:'1'}]);
 const fields="'ANTHROPIC_DEFAULT_OPUS_MODEL=claude-opus-5-5' 'CLAUDE_CODE_DISABLE_REFUSAL_FALLBACK=1'";
 await publish('exec /usr/bin/env -i '+quote('DECOY='+fields)+" '/bin/true'\n");
 await publish('unrelated '+fields+'\n');
 await publish("exec /usr/bin/env -i 'ANTHROPIC_DEFAULT_OPUS_MODEL=claude-opus-5-5' '/bin/true'\n");
 await publish("exec /usr/bin/env -i 'ANTHROPIC_DEFAULT_OPUS_MODEL=claude-opus-5-5' 'CLAUDE_CODE_DISABLE_REFUSAL_FALLBACK=0' '/bin/true'\n");
 await publish('exec /usr/bin/env -i '+fields+" 'CLAUDE_CODE_DISABLE_REFUSAL_FALLBACK=1' '/bin/true'\n");
 assert.equal(observer.rows.length,1);assert.equal(observer.errors.length,5);
 const sub=join(root,'unrelated');mkdirSync(sub);await publish('exec /usr/bin/env -i '+fields+" '/bin/true'\n",sub);
 assert.equal(observer.rows.length,1);assert.equal(observer.errors.length,5);
 const other=join(root,'other.txt');writeFileSync(other,'plain');assert.equal(await fsPromises.rename(other,other+'.renamed'),undefined);
 let rejection;try{await fsPromises.rename(join(root,'missing'),join(root,'missing.gate'));}catch(error){rejection=error;}
 assert.equal(rejection?.code,'ENOENT');assert.equal(observer.errors.length,5);
 assert(!JSON.stringify(observer).includes('NEVER_RETAIN_ME'));
 console.log(JSON.stringify({result:'PASS',realGate:true,childAndPipesJoined:true,onlyTwoSettings:true,secretAbsent:true,decoyRejected:true,malformedRejected:true,missingWrongDuplicateRejected:true,unrelatedRenamesIgnored:true,originalRenameRejectionPreserved:true,observerFailuresSeparated:true}));
}finally{if(gate)await gate.closeAndJoin();observer.restore();rmSync(root,{recursive:true,force:true});}
