# Explicit model refusal fallback fix — frozen implementation

Worktree: /Volumes/DevSSD/meridian/fix-explicit-model-fallback-20261103
Branch: fix/explicit-model-fallback-20261103
Base HEAD: 697f9482c23865e9d9a02095e35d79b0922047a7 (origin/main)

## Scope
- src/proxy/models.ts: explicitModelPin now returns existing requested per-tier pin plus CLAUDE_CODE_DISABLE_REFUSAL_FALLBACK=1 for the same previously recognized explicitly versioned Claude IDs. Existing trimming/case normalization/[1m] stripping and Mythos-to-Fable mapping are unchanged.
- src/__tests__/explicit-model-pins.test.ts: exact expected override objects include only the per-tier pin plus the fallback switch; opus[1m] and claude-opus controls remain undefined.
- src/__tests__/proxy-env-stripping.test.ts: narrow mocked HTTP controls cover inherited fallback=false overridden by explicit claude-opus-5-5, inherited setting preserved for bare opus, unset switch preserved for bare sonnet, explicit streaming delivery, and CLAUDE_CODE_DISABLE_REFUSAL_RETRY unchanged from inherited environment.
- No stripping/orchestration changes required: server.ts passes explicitModelPin as envOverrides, and query.ts spreads envOverrides last after inherited/profile env.

## Verification
- Red before production edit: bun test --timeout 30000 src/__tests__/explicit-model-pins.test.ts src/__tests__/proxy-env-stripping.test.ts — exit 1, 36 pass / 5 fail (four unit object groups and the inherited-false explicit HTTP control).
- Green: same command — exit 0, 41 pass / 0 fail / 82 expects.
- Green: bun test --timeout 30000 src/__tests__/models.test.ts — exit 0, 99 pass / 0 fail / 188 expects.
- Green: npm run typecheck — exit 0.
- Green: git diff --check — exit 0.
- Logs alongside this report: red-tests.log, focused-tests.log, models-tests.log, typecheck.log.

## Assumptions and limits
- Flag semantics derive from the parent's native 2.1.296 investigation: alternate-model refusal fallback only, not refusals, same-model refusal retry, or model-access fallback. No independent native source inspection or live model call was performed in this delegated task.
- This is an internal model-identity fix, not a claim that E41 is fixed. Parent owns adversarial review, actual source/package E2E, full suite, build, final-head CI and any commit/PR.
- No constants, timeouts, dependencies, public routes/interfaces or settings were changed. No CLAUDE_CODE_DISABLE_REFUSAL_RETRY or safety flags were introduced in production.
- No network/model/grant operations, commits, pushes, contributor commits, candidate edits, user checkout edits or launcher-branch edits.
- Development-only ignored node_modules symlink points to /Volumes/DevSSD/meridian/review-1220-20261103/node_modules.

## Frozen SHA256
- `src/proxy/models.ts`: `d6216e56b0034a3182e6aaf270dc8977ea130ffee58025fa76a39fbace34769f`
- `src/__tests__/explicit-model-pins.test.ts`: `02f7faece3a34083f8b4febf1c41bdb8d7692b68a8a3cdd4e0d9908ba48bb1f4`
- `src/__tests__/proxy-env-stripping.test.ts`: `c3416da794bb3c36d81f6bc281d927036fbad3aac210bb26a47164cca8bd026a`
