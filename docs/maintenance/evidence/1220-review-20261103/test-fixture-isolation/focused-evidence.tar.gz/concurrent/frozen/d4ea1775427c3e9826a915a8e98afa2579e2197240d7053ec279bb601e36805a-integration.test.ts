/**
 * Integration Tests — Real HTTP requests against the proxy
 *
 * These tests start the actual proxy server and send real HTTP requests
 * to verify the full request/response cycle works correctly.
 *
 * Note: These do NOT hit the real Claude API — they still mock the SDK.
 * But they test the full Hono HTTP stack, SSE parsing, etc.
 */

import { describe, it, expect, beforeAll, afterAll, beforeEach, afterEach } from "bun:test"
import { installSdkMock } from "./sdkMock"
import { installLoggerMock } from "./loggerMock"
import { installMcpToolsMock } from "./mcpToolsMock"
import {
  messageStart,
  textBlockStart,
  toolUseBlockStart,
  textDelta,
  inputJsonDelta,
  blockStop,
  messageDelta,
  messageStop,
  assistantMessage,
  parseSSE,
  withMockSdkSessionId,
} from "./helpers"

// --- Mock SDK ---
let mockMessages: any[] = []
let capturedQueryParams: any = null
type MockQueryParams = Parameters<typeof import("@anthropic-ai/claude-agent-sdk").query>[0]

installSdkMock(() => ({
  query: (params: MockQueryParams) => {
    capturedQueryParams = params
    return (async function* () {
      for (const msg of mockMessages) {
        yield withMockSdkSessionId(msg, params.options)
      }
    })()
  },
  createSdkMcpServer: () => ({
    type: "sdk",
    name: "test",
    instance: {},
  }),
  tool: () => ({}),
}), "integration.test.ts")

installLoggerMock(() => ({}))

installMcpToolsMock(() => ({
  createOpencodeMcpServer: () => ({ type: "sdk", name: "opencode", instance: {} }),
}))

const { createProxyServer } = await import("../proxy/server")

// Use Hono's built-in test client
function createTestApp() {
  const { app } = createProxyServer({ port: 0, host: "127.0.0.1" })
  return app
}

async function post(app: any, body: any) {
  return app.fetch(new Request("http://localhost/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-api-key": "dummy" },
    body: JSON.stringify(body),
  }))
}

async function readStream(response: Response): Promise<string> {
  const reader = response.body!.getReader()
  const decoder = new TextDecoder()
  let result = ""
  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    result += decoder.decode(value, { stream: true })
  }
  return result
}

// ============================================================
// FULL TOOL LOOP SIMULATION
// ============================================================

describe("Integration: Full Anthropic API tool loop", () => {
  let app: any
  let savedPassthrough: string | undefined

  beforeAll(() => {
    app = createTestApp()
  })

  beforeEach(() => {
    savedPassthrough = process.env.MERIDIAN_PASSTHROUGH
    process.env.MERIDIAN_PASSTHROUGH = "0"
    mockMessages = []
    capturedQueryParams = null
  })

  afterEach(() => {
    if (savedPassthrough !== undefined) process.env.MERIDIAN_PASSTHROUGH = savedPassthrough
    else delete process.env.MERIDIAN_PASSTHROUGH
  })

  it("Step 1: Initial request → Claude responds with tool_use", async () => {
    mockMessages = [
      assistantMessage([
        { type: "text", text: "I'll read that file." },
        { type: "tool_use", id: "toolu_abc", name: "Read", input: { file_path: "package.json" } },
      ]),
    ]

    const response = await post(app, {
      model: "claude-sonnet-4-5",
      max_tokens: 1024,
      stream: false,
      messages: [{ role: "user", content: "Read package.json" }],
      tools: [{
        name: "Read",
        description: "Read a file",
        input_schema: { type: "object", properties: { file_path: { type: "string" } }, required: ["file_path"] },
      }],
    })

    const body = await response.json() as any
    expect(response.status).toBe(200)
    expect(body.stop_reason).toBe("tool_use")
    expect(body.content).toHaveLength(2)
    expect(body.content[0].type).toBe("text")
    expect(body.content[1].type).toBe("tool_use")
    expect(body.content[1].name).toBe("Read")
    expect(body.content[1].id).toBe("toolu_abc")
  })

  it("Step 2: Send tool_result → Claude responds with final text", async () => {
    mockMessages = [
      assistantMessage([
        { type: "text", text: "The project is meridian version 1.1.0" },
      ]),
    ]

    const response = await post(app, {
      model: "claude-sonnet-4-5",
      max_tokens: 1024,
      stream: false,
      messages: [
        { role: "user", content: "Read package.json" },
        { role: "assistant", content: [
          { type: "text", text: "I'll read that file." },
          { type: "tool_use", id: "toolu_abc", name: "Read", input: { file_path: "package.json" } },
        ]},
        { role: "user", content: [
          { type: "tool_result", tool_use_id: "toolu_abc", content: '{"name":"meridian","version":"1.1.0"}' },
        ]},
      ],
    })

    const body = await response.json() as any
    expect(response.status).toBe(200)
    expect(body.stop_reason).toBe("end_turn")
    expect(body.content[0].type).toBe("text")
    expect(body.content[0].text).toContain("meridian")

    // Verify the prompt includes the tool result
    expect(capturedQueryParams.prompt).toContain("meridian")
    expect(capturedQueryParams.prompt).toContain("1.1.0")
  })

  it("Step 3: Error tool_result → Claude recovers", async () => {
    mockMessages = [
      assistantMessage([
        { type: "text", text: "I see the agent type was invalid. Let me try with a different approach." },
        { type: "tool_use", id: "toolu_retry", name: "Bash", input: { command: "cat README.md | head -5" } },
      ]),
    ]

    const response = await post(app, {
      model: "claude-sonnet-4-5",
      max_tokens: 1024,
      stream: false,
      messages: [
        { role: "user", content: "use a subagent to read README" },
        { role: "assistant", content: [
          { type: "tool_use", id: "toolu_task1", name: "Task", input: { agent_type: "general-purpose", prompt: "read README" } },
        ]},
        { role: "user", content: [
          { type: "tool_result", tool_use_id: "toolu_task1", content: "Error: Unknown agent type: general-purpose is not a valid agent type", is_error: true },
        ]},
      ],
    })

    const body = await response.json() as any
    expect(response.status).toBe(200)
    // Claude should recover with a new tool call or text
    expect(body.content.length).toBeGreaterThanOrEqual(1)
    // The prompt should contain the error so Claude can learn from it
    expect(capturedQueryParams.prompt).toContain("Unknown agent type")
  })
})

// ============================================================
// STREAMING TOOL LOOP
// ============================================================

describe("Integration: Streaming tool loop", () => {
  let app: any

  beforeAll(() => {
    app = createTestApp()
  })

  beforeEach(() => {
    mockMessages = []
  })

  it("should stream tool_use blocks with proper SSE format", async () => {
    mockMessages = [
      messageStart("msg_stream_tool"),
      textBlockStart(0),
      textDelta(0, "Reading file..."),
      blockStop(0),
      toolUseBlockStart(1, "Read", "toolu_stream1"),
      inputJsonDelta(1, '{"file_path":'),
      inputJsonDelta(1, '"src/index.ts"}'),
      blockStop(1),
      messageDelta("tool_use"),
      messageStop(),
    ]

    const response = await post(app, {
      model: "claude-sonnet-4-5",
      max_tokens: 1024,
      stream: true,
      messages: [{ role: "user", content: "Read src/index.ts" }],
    })

    expect(response.status).toBe(200)
    expect(response.headers.get("content-type")).toContain("text/event-stream")

    const text = await readStream(response)
    const events = parseSSE(text)

    // Should have message_start
    const msgStart = events.find(e => e.event === "message_start")
    expect(msgStart).toBeDefined()

    // Should have text content
    const textDeltas = events.filter(e =>
      e.event === "content_block_delta" && (e.data as any).delta?.type === "text_delta"
    )
    expect(textDeltas.length).toBe(1)
    expect((textDeltas[0]?.data as any).delta.text).toBe("Reading file...")

    // Should have tool_use content block
    const toolStarts = events.filter(e =>
      e.event === "content_block_start" && (e.data as any).content_block?.type === "tool_use"
    )
    expect(toolStarts.length).toBe(1)
    expect((toolStarts[0]?.data as any).content_block.name).toBe("Read")

    // Should have input_json_delta events
    const jsonDeltas = events.filter(e =>
      e.event === "content_block_delta" && (e.data as any).delta?.type === "input_json_delta"
    )
    expect(jsonDeltas.length).toBe(2)

    // Should have tool_use stop_reason
    const msgDelta = events.find(e => e.event === "message_delta")
    expect((msgDelta?.data as any).delta.stop_reason).toBe("tool_use")
  })
})

// ============================================================
// NON-STREAM USAGE PROPAGATION
// ============================================================

describe("Integration: Non-stream usage propagation", () => {
  let app: any

  beforeAll(() => {
    app = createTestApp()
  })

  beforeEach(() => {
    mockMessages = []
  })

  it("forwards input/output tokens from the SDK assistant message", async () => {
    mockMessages = [
      assistantMessage([{ type: "text", text: "Done." }]),
    ]

    const response = await post(app, {
      model: "claude-sonnet-4-5",
      max_tokens: 1024,
      stream: false,
      messages: [{ role: "user", content: "ping" }],
    })

    const body = await response.json() as any
    expect(response.status).toBe(200)
    // `assistantMessage` helper seeds usage with input=10, output=50
    expect(body.usage.input_tokens).toBe(10)
    expect(body.usage.output_tokens).toBe(50)
  })

  it("forwards cache tokens when present", async () => {
    mockMessages = [
      {
        type: "assistant",
        message: {
          id: "msg_test",
          type: "message",
          role: "assistant",
          content: [{ type: "text", text: "Cached." }],
          model: "claude-sonnet-4-5-20250929",
          stop_reason: "end_turn",
          usage: {
            input_tokens: 3,
            output_tokens: 12,
            cache_read_input_tokens: 28933,
            cache_creation_input_tokens: 0,
          },
        },
        parent_tool_use_id: null,
        uuid: crypto.randomUUID(),
        session_id: "test-session",
      } as any,
    ]

    const response = await post(app, {
      model: "claude-sonnet-4-5",
      max_tokens: 1024,
      stream: false,
      messages: [{ role: "user", content: "ping" }],
    })

    const body = await response.json() as any
    expect(response.status).toBe(200)
    expect(body.usage.input_tokens).toBe(3)
    expect(body.usage.output_tokens).toBe(12)
    expect(body.usage.cache_read_input_tokens).toBe(28933)
    expect(body.usage.cache_creation_input_tokens).toBe(0)
  })

  it("falls back to zeros when no SDK assistant message is produced", async () => {
    mockMessages = []

    const response = await post(app, {
      model: "claude-sonnet-4-5",
      max_tokens: 1024,
      stream: false,
      messages: [{ role: "user", content: "ping" }],
    })

    expect({ status: response.status, body: response.status === 200 ? undefined : await response.clone().text() })
      .toEqual({ status: 200, body: undefined })
    const body = await response.json() as any
    expect(body.usage.input_tokens).toBe(0)
    expect(body.usage.output_tokens).toBe(0)
  })
})

// ============================================================
// NATIVE SERVER-TOOL FAIL-FAST (#488 / #481)
// ============================================================

describe("Integration: native server tools fail fast", () => {
  let app: any
  let savedPassthrough: string | undefined

  beforeAll(() => {
    app = createTestApp()
  })

  beforeEach(() => {
    savedPassthrough = process.env.MERIDIAN_PASSTHROUGH
    process.env.MERIDIAN_PASSTHROUGH = "0"
    mockMessages = []
  })

  afterEach(() => {
    if (savedPassthrough !== undefined) process.env.MERIDIAN_PASSTHROUGH = savedPassthrough
    else delete process.env.MERIDIAN_PASSTHROUGH
  })

  it("rejects a request carrying the native web_search server tool with an actionable 400", async () => {
    const response = await post(app, {
      model: "claude-sonnet-4-5",
      max_tokens: 1024,
      stream: false,
      messages: [{ role: "user", content: "search the web" }],
      tools: [{ type: "web_search_20250305", name: "web_search", max_uses: 8 }],
    })

    const body = await response.json() as any
    expect(response.status).toBe(400)
    expect(body.error.type).toBe("invalid_request_error")
    expect(body.error.message).toContain("web_search_20250305")
    expect(body.error.message).toContain("api.anthropic.com")
    expect(body.error.message).toContain("ANTHROPIC_API_KEY")
  })

  it("does not reject ordinary custom/passthrough tools", async () => {
    mockMessages = [assistantMessage([{ type: "text", text: "ok" }])]

    const response = await post(app, {
      model: "claude-sonnet-4-5",
      max_tokens: 1024,
      stream: false,
      messages: [{ role: "user", content: "read a file" }],
      tools: [{ name: "web-search", description: "opencode custom tool", input_schema: { type: "object", properties: { query: { type: "string" } } } }],
    })

    // The custom tool must not trip the server-tool fail-fast (it's a client tool, not a server tool).
    expect(response.status).not.toBe(400)
  })
})

// ============================================================
// CHERRY STUDIO ADAPTER — web search unblocked (#481)
// ============================================================

async function postAs(app: any, agent: string, body: any) {
  return app.fetch(new Request("http://localhost/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-api-key": "dummy", "x-meridian-agent": agent },
    body: JSON.stringify(body),
  }))
}

describe("Integration: Cherry Studio web search", () => {
  let app: any

  beforeAll(() => {
    app = createTestApp()
  })

  beforeEach(() => {
    mockMessages = [assistantMessage([{ type: "text", text: "Node.js 24 is the latest LTS." }])]
    capturedQueryParams = null
  })

  it("invokes the SDK with WebSearch/WebFetch ALLOWED and NOT disallowed", async () => {
    const response = await postAs(app, "cherry", {
      model: "claude-sonnet-4-5",
      max_tokens: 1024,
      stream: false,
      messages: [{ role: "user", content: "search the web for the latest node LTS" }],
    })

    expect(response.status).toBe(200)
    const opts = capturedQueryParams.options
    // Web tools are in the allowlist...
    expect(opts.allowedTools).toContain("WebSearch")
    expect(opts.allowedTools).toContain("WebFetch")
    // ...and NOT blocked.
    expect(opts.disallowedTools).not.toContain("WebSearch")
    expect(opts.disallowedTools).not.toContain("WebFetch")
    // Other built-ins stay blocked.
    expect(opts.disallowedTools).toContain("Bash")
  })

  it("hides the SDK's internal WebSearch tool_use + thinking, returning only the final answer", async () => {
    // Simulate the SDK's internal loop: turn 1 thinks + calls WebSearch, turn 2
    // returns the grounded text. The client must see only the text.
    mockMessages = [
      assistantMessage([
        { type: "thinking", thinking: "Let me search.", signature: "sig" },
        { type: "tool_use", id: "srch1", name: "WebSearch", input: { query: "node lts" } },
      ]),
      assistantMessage([{ type: "text", text: "Node.js 24 is the latest LTS." }]),
    ]

    const response = await postAs(app, "cherry", {
      model: "claude-sonnet-4-5",
      max_tokens: 512,
      stream: false,
      messages: [{ role: "user", content: "latest node LTS?" }],
    })

    const body = await response.json() as any
    expect(response.status).toBe(200)
    expect(body.content.map((b: any) => b.type)).toEqual(["text"])
    expect(body.content[0].text).toContain("Node.js 24")
    expect(body.stop_reason).toBe("end_turn")
  })
})
