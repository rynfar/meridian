import assert from 'node:assert/strict';
import { AsyncLocalStorage } from 'node:async_hooks';
import { mkdirSync,writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { mock,spyOn } from 'bun:test';
import { createRequestModelWitness } from "/Users/rynfar/repos/meridian-claude-auxiliary-1211-20261004/scripts/e2e-claude-code-auto-mode.mjs";
const root="/var/folders/ks/xnz659y11jl44j80b_lfws6r0000gn/T/meridian-e71-actual-context-JG7Rey",entry="/Users/rynfar/repos/meridian-claude-auxiliary-1211-20261004/dist/server.js",modelEntry="/Users/rynfar/repos/meridian-claude-auxiliary-1211-20261004/dist/cli-09zvfxm4.js",mode="duplicate";
for(const key of Object.keys(process.env))if(/^(CLAUDE|ANTHROPIC|MERIDIAN|CLAUDE_PROXY|OPENAI|AWS_|GOOGLE_|VERTEX_|BEDROCK_|NODE_OPTIONS|BUN_OPTIONS|OPENCODE_)/.test(key))delete process.env[key];
for(const directory of ['home','config','store','work','claude','plugins'])mkdirSync(join(root,directory),{mode:0o700});
Object.assign(process.env,{HOME:join(root,'home'),CLAUDE_CONFIG_DIR:join(root,'claude'),MERIDIAN_CONFIG_DIR:join(root,'config'),MERIDIAN_SESSION_DIR:join(root,'store'),MERIDIAN_WORKDIR:join(root,'work'),MERIDIAN_TEST_DISABLE_SDK_PROCESS_GATE:'1',MERIDIAN_ROUTING:'active',MERIDIAN_PASSTHROUGH:'1',MERIDIAN_TELEMETRY_PERSIST:'0',MERIDIAN_NO_UPDATE_CHECK:'1',MERIDIAN_CREDENTIALS_READONLY:'1',MERIDIAN_MAX_CONCURRENT:'4',MERIDIAN_SHUTDOWN_GRACE_MS:'1000'});
for(const kind of ['CONFIG','DATA','CACHE','STATE']){const directory=join(root,'xdg-'+kind);mkdirSync(directory,{mode:0o700});process.env['XDG_'+kind+'_HOME']=directory}
writeFileSync(join(root,'config/settings.json'),'{}');writeFileSync(join(root,'config/profiles.json'),'[]');writeFileSync(join(root,'plugins.json'),'{}');
const main={request:1,role:'main',requestedModel:'claude-sonnet-5-5'},classifier={request:2,role:'classifier',requestedModel:'claude-sonnet-5'};
const known=new Map([['synthetic-actual-main',main],['synthetic-actual-classifier',classifier]]),descriptor=Object.getOwnPropertyDescriptor(AsyncLocalStorage.prototype,'run'),witness=createRequestModelWitness(known),observations=[],active=new Set(),controls=[];
let proxy,auth,executable,externalFetchAttempts=0,failed=false,restored=false;
const originalFetch=globalThis.fetch;
globalThis.fetch=(input,options)=>{const url=new URL(input instanceof Request?input.url:String(input));if(url.hostname!=='127.0.0.1'){externalFetchAttempts++;throw new Error('External traffic fenced in actual-target synthetic control')}return originalFetch(input,options)};
const sdkPath=createRequire(entry).resolve('@anthropic-ai/claude-agent-sdk');
mock.module(sdkPath,()=>({
 query(input){const owned=witness.capture(),matched=input.options.model===owned.requestedModel||(input.options.model==='sonnet'&&input.options.env?.ANTHROPIC_DEFAULT_SONNET_MODEL===owned.requestedModel);observations.push({request:owned.request,role:owned.role,requested:owned.requestedModel,sdk:input.options.model,versionPin:input.options.env?.ANTHROPIC_DEFAULT_SONNET_MODEL,matched});assert(matched,'Actual target SDK query differs from its exact logger-owned wire model');let release;const held=new Promise(resolve=>{release=resolve});controls.push(release);if(controls.length===2)controls.forEach(fn=>fn());const session=input.options.sessionId??input.options.resume??crypto.randomUUID();const generator=(async function*(){active.add(generator);try{yield{type:'system',subtype:'init',session_id:session};if(mode==='positive')await held;yield{type:'assistant',uuid:crypto.randomUUID(),session_id:session,message:{id:'synthetic-msg',type:'message',role:'assistant',model:owned.requestedModel,content:[{type:'text',text:'synthetic complete'}],usage:{input_tokens:12,output_tokens:4},stop_reason:'end_turn'}};yield{type:'result',subtype:'success',is_error:false,session_id:session,num_turns:1,total_cost_usd:0.001,usage:{input_tokens:12,output_tokens:4}}}finally{active.delete(generator)}})();return Object.assign(generator,{close:release})},
 createSdkMcpServer:input=>({type:'sdk',name:input.name,instance:{tool(){},registerTool(){return{}},connect(){}}}),tool:(name,description,inputSchema,handler)=>({name,description,inputSchema,handler})
}));
const targetModels=await import(pathToFileURL(modelEntry).href);
auth=spyOn(targetModels,'getClaudeAuthStatusAsync').mockResolvedValue({loggedIn:true,subscriptionType:'max'});
executable=spyOn(targetModels,'resolveClaudeExecutableAsync').mockResolvedValue(join(root,'never-executed-native'));
try{
 const {startProxyServer}=await import(pathToFileURL(entry).href);
 proxy=await startProxyServer({host:'127.0.0.1',port:0,silent:true,profiles:[{id:'fixture',type:'api',apiKey:'synthetic-non-auth-fixture'}],defaultProfile:'fixture',pluginDir:join(root,'plugins'),pluginConfigPath:join(root,'plugins.json')});
 const address=proxy.server.address();assert(address&&typeof address==='object');
 const session=crypto.randomUUID(),envelope='You are a security monitor for autonomous AI coding agents.\n<cc_automode_permissions>\nSynthetic rules.\n</cc_automode_permissions>';
 const post=async(which,id)=>{const auxiliary=which.role==='classifier',body={model:which.requestedModel,max_tokens:128,stream:false,metadata:{user_id:JSON.stringify({session_id:mode==='duplicate'?crypto.randomUUID():session})},messages:[{role:'user',content:'synthetic '+which.role}],tools:[],...(auxiliary?{system:[{type:'text',text:envelope}],stop_sequences:['</block>']}:{})};const response=await fetch('http://127.0.0.1:'+address.port+'/v1/messages',{method:'POST',headers:{'content-type':'application/json','user-agent':'claude-cli/2.1.286','x-request-id':id,'x-meridian-profile':'fixture',...(auxiliary?{'x-claude-code-request-class':'auxiliary'}:{'x-claude-code-request-class':'main'})},body:JSON.stringify(body)});await response.text();return response.status};
 const pairs=mode==='duplicate'?[[main,'synthetic-actual-main'],[main,'synthetic-actual-main']]:[[main,mode==='swap'?'synthetic-actual-classifier':'synthetic-actual-main'],[classifier,mode==='swap'?'synthetic-actual-main':mode==='unmatched'?'synthetic-unmatched':'synthetic-actual-classifier']];
 const statuses=await Promise.all(pairs.map(([which,id])=>post(which,id)));
 if(mode==='positive'){assert(statuses.every(status=>status===200));assert(observations.length===2&&observations.every(row=>row.matched));assert(witness.summary().capturedRequests===2)}
 else if(mode==='swap'){assert(statuses.every(status=>status>=500));assert(observations.length===2&&observations.every(row=>!row.matched))}
 else {assert(statuses.some(status=>status>=500));assert(witness.summary()[mode==='duplicate'?'duplicateContext':'missingContext'])}
 writeFileSync("/var/folders/ks/xnz659y11jl44j80b_lfws6r0000gn/T/meridian-e71-actual-context-JG7Rey/results.json",JSON.stringify({kind:"compiled",mode,statuses,observations,summary:witness.summary(),entrySha256:"bef43f1954ed3d56b69fea5d23245032035287cb42be93733ac8e2bee8a34b29",modelModuleSha256:"414c8f5f4df309bd940bfe945479ff260718e0179f4bab67b77611b6c5f41f87",compiledSourceHead:"80d1ce8158dc7cd466a87863404bf6ea02754c8b"}));
}catch(error){failed=true;throw error}finally{
 controls.forEach(fn=>fn());if(proxy)await proxy.close();assert(active.size===0,'Synthetic SDK generator did not join');auth?.mockRestore();executable?.mockRestore();witness.restore();restored=witness.isRestored();assert.deepEqual(Object.getOwnPropertyDescriptor(AsyncLocalStorage.prototype,'run'),descriptor);globalThis.fetch=originalFetch;
 if(!failed){const {readFileSync}=await import('node:fs');const report=JSON.parse(readFileSync("/var/folders/ks/xnz659y11jl44j80b_lfws6r0000gn/T/meridian-e71-actual-context-JG7Rey/results.json",'utf8'));Object.assign(report,{loggerDescriptorRestored:restored,joinedGenerators:true,externalFetchAttempts,authDiscovery:false,executableDiscovery:false});writeFileSync("/var/folders/ks/xnz659y11jl44j80b_lfws6r0000gn/T/meridian-e71-actual-context-JG7Rey/results.json",JSON.stringify(report));assert(externalFetchAttempts===0)}
}
