import {spyOn} from 'bun:test';
import {writeFileSync} from 'node:fs';
import {join} from 'node:path';
const root=process.env.E71_CLONE_CONTROL_DIR;
if(!root)throw new Error('Synthetic cancellation fixture root required');
const original=Response.prototype.clone;
let injected=false;
spyOn(Response.prototype,'clone').mockImplementation(function(){
 if(injected)return Reflect.apply(original,this,[]);
 injected=true;
 writeFileSync(join(root,'clone-receipt-entered'),'synthetic clone-only receipt entered');
 return {body:{getReader(){return {
  read:()=>Promise.reject(new Error('synthetic cloned read failure')),
  cancel:()=>{writeFileSync(join(root,'clone-cancellation-entered'),'synthetic clone cancellation entered');return new Promise(()=>{})},
  releaseLock(){}
 }}}};
});
