from pathlib import Path
import subprocess,json,os,socket,hashlib,shutil,signal
root=Path('/private/tmp/meridian-1426-approved-20261021');out=Path('/tmp/meridian-approved-actions-20261021');bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun'
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'cases':[],'result':'RUNNING'}
def save():(out/'1426-openai.json').write_text(json.dumps(record,indent=2)+'\n')
try:
 for mode in ['json','stream','e58']:
  target=out/('openai-'+mode);assert not target.exists();target.mkdir()
  for d in ['home','native-config']:(target/d).mkdir(mode=0o700)
  subprocess.run([bun,str(out/'prepare-live-grant.mjs')],cwd=root,check=True)
  admission=json.loads((out/'1426-live-admission.json').read_text());sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
  env={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']};env.update(HOME=str(target/'home'),CLAUDE_CONFIG_DIR=str(target/'native-config'),MERIDIAN_CLAUDE_PATH=admission['native']['path'],MERIDIAN_CREDENTIALS_READONLY='1',MERIDIAN_NO_UPDATE_CHECK='1',E2E_MERIDIAN_ROOT=str(root),E2E_MODEL_WITNESS=str(target/'model-witness.json'),E2E_ALLOW_LIVE_MODEL='1',E2E_LIVE_PROFILE_FILE=str(out/'private/access-only.json'),E2E_USAGE_GUARD_FILE=str(out/'1426-live-admission.json'),PROBE_MODEL='claude-haiku-4-5-20251001',PROBE_PORT=str(port))
  row={'mode':mode,'admission':admission};record['cases'].append(row);save()
  script='run-e58.mjs'if mode=='e58'else'run-openai.mjs'
  with(target/'run.log').open('w')as log:
   process=subprocess.Popen([bun,str(out/'qualified-e41'/script)]+(['--stream']if mode=='stream'else[]),cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['controllerPID']=process.pid;save()
   try:code=process.wait(timeout=300)
   except subprocess.TimeoutExpired:
    row['timeout']=True;os.killpg(process.pid,signal.SIGTERM)
    try:code=process.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=10)
  result=next((json.loads(line)for line in reversed((target/'run.log').read_text().splitlines())if line.startswith('{"root":')),None);report={}
  if result:report=json.loads((Path(result['root'])/('e58-report.json'if mode=='e58'else'openai-report.json')).read_text());(target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
  witness=json.loads((target/'model-witness.json').read_text())if(target/'model-witness.json').exists()else{};identities=[]
  for provider in witness.get('provider',[]):
   for event in provider.get('events',[]):
    if event.get('type')!='message_start':continue
    query=provider['query'];model=event.get('model');identities.append({'query':query,'providerID':event.get('id'),'model':model,'status':provider.get('status'),'child':any(c['query']==query and c.get('closed')for c in witness['children']),'nativeInit':any(n['query']==query and n.get('type')=='init'and n.get('model','').replace('[1m]','')==model for n in witness['native']),'nativeMessage':any(n['query']==query and n.get('id')==event.get('id')and n.get('model')==model for n in witness['native']),'publicStored':any(n.get('id')==event.get('id')and n.get('model')==model for store in witness['stored']for n in store['rows'])})
  (target/'identity-correlation.json').write_text(json.dumps(identities,indent=2)+'\n');generations=witness.get('generationCount',0);correlated=len(identities)==generations>0 and all(x['model']=='claude-haiku-4-5-20251001'and x['status']==200 and x['child']and x['nativeInit']and x['nativeMessage']for x in identities)
  row.update(exit=code,result=result,assertions=report.get('result'),generations=generations,realForwards=witness.get('realForwards',0),joined=report.get('joined'),correlated=correlated,stopped=witness.get('stopped'))
  row['nativeUnchanged']=hashlib.sha256(Path(admission['native']['path']).read_bytes()).hexdigest()==admission['native']['SHA256']
  row['qualified']=row['nativeUnchanged']and code==0 and report.get('result')=='PASS'and row['joined']and correlated and witness.get('closed')and not witness.get('stopped')and 0<generations<=12 and row['realForwards']==generations
  save();print(json.dumps({k:v for k,v in row.items()if k!='admission'}),flush=True);assert row['qualified'],'Preserve exact failure; no retry/model/account switch'
  fixture=Path(result['root']);assert fixture.name.startswith(('meridian-1426-openai-','mtoolloop-'))and not fixture.is_symlink();shutil.rmtree(fixture)
  for d in ['home','native-config']:shutil.rmtree(target/d)
  row['fixtureRemoved']=True;save()
 record['result']='PASS'
finally:
 if record['result']!='PASS':record['result']='FAIL'
 save();print(json.dumps({'result':record['result'],'cases':len(record['cases'])}),flush=True)
