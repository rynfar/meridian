from pathlib import Path
import subprocess,json,time,os,hashlib,re
root=Path('/private/tmp/meridian-1426-approved-20261021');out=Path('/tmp/meridian-approved-actions-20261021');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip();tar=Path('/tmp/meridian-release-20261019/registry-1.84.0.tgz');SHA256='0bc7e56683ec375bf4aba02c09f2275db1e5310dcc05bf5274b528335fc2ed3d';assert hashlib.sha256(tar.read_bytes()).hexdigest()==SHA256
env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib',BOOKKEEPING_COMPAT_TARBALL=str(tar));env['PATH']='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin:'+env['PATH'];rows=[]
for label,command in [('typecheck',['npm','run','typecheck']),('build',['npm','run','build']),('full',['npm','test'])]:
 start=time.monotonic();print('Starting '+label+' on '+head,flush=True)
 with(out/('1426-r2-'+label+'.log')).open('w')as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':label,'exit':result.returncode,'seconds':time.monotonic()-start};rows.append(row);(out/'1426-r2-local.json').write_text(json.dumps({'head':head,'tarSHA256':SHA256,'commands':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
 if result.returncode:break
 if label=='full':
  text=(out/'1426-r2-full.log').read_text();counts={'pass':sum(map(int,re.findall(r'^\s*(\d+) pass\s*$',text,re.M))),'skip':sum(map(int,re.findall(r'^\s*(\d+) skip\s*$',text,re.M))),'fail':sum(map(int,re.findall(r'^\s*(\d+) fail\s*$',text,re.M))),'groups':len(re.findall(r'^Ran \d+ tests',text,re.M))};(out/'1426-r2-counts.json').write_text(json.dumps(counts,indent=2)+'\n');assert counts['groups']==26 and counts['fail']==0
