// Manual live OpenAI HTTP fixture. Synthetic files only; no private SDK files.
import assert from 'node:assert/strict'
import {mkdtempSync,mkdirSync,readFileSync,writeFileSync,realpathSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {pathToFileURL} from 'node:url'
import {createRequire} from 'node:module'
import {createHash,randomUUID} from 'node:crypto'
import * as cp from 'node:child_process'
import {spyOn} from 'bun:test'
import {installModelObserver} from './e41-model-observer.mjs'
const ROOT=process.env.E2E_MERIDIAN_ROOT,MODEL='claude-haiku-4-5-20251001',STREAM=process.argv.includes('--stream'),PORT=Number(process.env.PROBE_PORT)
assert(ROOT&&process.env.E2E_ALLOW_LIVE_MODEL==='1')
const observer=await installModelObserver(ROOT,process.env.E2E_MODEL_WITNESS,MODEL)
const {observeChildClosure,stopAndJoinChild}=await import(pathToFileURL(ROOT+'/scripts/lib/e2eProcessCustody.mjs'))
const actors=[],spies=[]
for(const name of ['spawn','execFile']){const original=cp[name];spies.push(spyOn(cp,name).mockImplementation((...args)=>{const child=Reflect.apply(original,cp,args);actors.push({child,witness:observeChildClosure(child)});return child}))}
for(const key of Object.keys(process.env))if(/^(MERIDIAN_|CLAUDE_PROXY_|ANTHROPIC_|CLAUDE_)/.test(key)&&!['MERIDIAN_CLAUDE_PATH','MERIDIAN_CREDENTIALS_READONLY','MERIDIAN_NO_UPDATE_CHECK','CLAUDE_CONFIG_DIR'].includes(key))delete process.env[key]
const WORK=realpathSync(mkdtempSync(join(tmpdir(),'meridian-1426-openai-'))),nonce=randomUUID()
process.env.MERIDIAN_WORKDIR=WORK;process.env.MERIDIAN_CONFIG_DIR=join(WORK,'config');mkdirSync(process.env.MERIDIAN_CONFIG_DIR)
process.env.MERIDIAN_PASSTHROUGH='1';process.env.MERIDIAN_DEFER_TOOL_THRESHOLD='0';process.env.MERIDIAN_TELEMETRY_PERSIST='0';process.env.OPENCODE_CLAUDE_PROVIDER_DEBUG='1'
const {setSessionStoreDir,readSessionStoreSnapshot}=await import(pathToFileURL(ROOT+'/src/proxy/sessionStore.ts'));setSessionStoreDir(join(WORK,'store'))
const {getSessionMessages}=await import(createRequire(ROOT+'/package.json').resolve('@anthropic-ai/claude-agent-sdk'))
const {startProxyServer}=await import(pathToFileURL(ROOT+'/src/proxy/server.ts'))
const say=console.log.bind(console),logs=[]
for(const key of ['log','error','debug','warn'])console[key]=(...args)=>logs.push(args.map(String).join(' '))
const key='generic-'+nonce,sourceHashes=new Map(),report={root:WORK,scope:'Generic OpenAI-compatible fetch HTTP client, real SDK/model; not the Shakespeare browser application',model:MODEL,stream:STREAM,requests:[],result:'RUNNING'}
const digest=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex')
const stored=id=>Object.entries(readSessionStoreSnapshot()).find(([k])=>k===id||k.endsWith(':'+id))?.[1]
async function history(source){assert(source?.claudeSessionId);const previous=process.env.CLAUDE_CONFIG_DIR;try{if(source.currentTranscript?.configDir)process.env.CLAUDE_CONFIG_DIR=source.currentTranscript.configDir;const rows=await getSessionMessages(source.claudeSessionId,{dir:source.currentTranscript?.projectDir??WORK});observer.recordStored(source,rows);assert(rows.length>0);return rows}finally{if(previous===undefined)delete process.env.CLAUDE_CONFIG_DIR;else process.env.CLAUDE_CONFIG_DIR=previous}}
async function snapshot(id){await new Promise(r=>setTimeout(r,1500));const source=structuredClone(stored(id)),rows=await history(source);if(sourceHashes.has(source.claudeSessionId))assert.equal(sourceHashes.get(source.claudeSessionId).SHA256,digest(rows),'Previously captured source changed');sourceHashes.set(source.claudeSessionId,{source,SHA256:digest(rows)});return {source,rows}}
const prefix=label=>`Owned session test ${label} ${nonce}. `+('This is a synthetic conversation identity and prompt cache qualification. Preserve every supplied tool result and conversation history. '.repeat(240))
const files=Object.fromEntries(['alpha','bravo','charlie'].map(name=>[join(WORK,name+'.txt'),name.toUpperCase()+'-VALUE']))
for(const [path,body]of Object.entries(files))writeFileSync(path,body+'\n')
const tools=[{type:'function',function:{name:'read',description:'Read exactly one named file from the owned test fixture.',parameters:{type:'object',properties:{file_path:{type:'string'}},required:['file_path']}}},...Array.from({length:22},(_,i)=>({type:'function',function:{name:'unused_'+i,description:`Unused cache prefix tool ${nonce} ${i}. `+'Not relevant to the requested operation. '.repeat(20),parameters:{type:'object',properties:{arg:{type:'string'}}}}}))]
let inst
async function post(label,messages,headers={},declared=[]){
 const before=logs.length,response=await fetch(`http://127.0.0.1:${PORT}/v1/chat/completions`,{method:'POST',headers:{'content-type':'application/json',...headers},body:JSON.stringify({model:MODEL,max_tokens:1024,stream:STREAM,stream_options:STREAM?{include_usage:true}:undefined,messages,tools:declared}),signal:AbortSignal.timeout(120000)})
 assert.equal(response.status,200,`${label}: HTTP ${response.status}; stop without another generation`)
 const raw=await response.text();let message,usage
 if(!STREAM){const body=JSON.parse(raw);assert(!body.error);message=body.choices?.[0]?.message;usage=body.usage}
 else {message={role:'assistant',content:'',tool_calls:[]};for(const frame of raw.split('\n').filter(line=>line.startsWith('data:'))){const data=frame.slice(5).trim();if(data==='[DONE]')continue;const chunk=JSON.parse(data);assert(!chunk.error,'In-band OpenAI error; stop');if(chunk.usage)usage=chunk.usage;const delta=chunk.choices?.[0]?.delta;if(!delta)continue;if(delta.content)message.content+=delta.content;for(const call of delta.tool_calls??[]){const current=message.tool_calls[call.index]??={id:'',type:'function',function:{name:'',arguments:''}};if(call.id)current.id+=call.id;if(call.function?.name)current.function.name+=call.function.name;if(call.function?.arguments)current.function.arguments+=call.function.arguments}}if(!message.tool_calls.length)delete message.tool_calls}
 assert(message&&typeof message==='object');assert(!observer.witness.stopped,observer.witness.stopped)
 const requestLine=logs.slice(before).find(line=>line.includes('[PROXY]')&&line.includes('adapter=')&&line.includes('msgCount='))??''
 const row={label,status:response.status,lineage:/lineage=(\S+)/.exec(requestLine)?.[1],session:/session=(\S+)/.exec(requestLine)?.[1],adapter:/adapter=(\S+)/.exec(requestLine)?.[1],messages:Number(/msgCount=(\d+)/.exec(requestLine)?.[1]),usage,toolIDs:(message.tool_calls??[]).map(call=>call.id)}
 assert.equal(row.adapter,'openai');report.requests.push(row);say(JSON.stringify(row));return {message,row}
}
try{
 const profiles=JSON.parse(readFileSync(process.env.E2E_LIVE_PROFILE_FILE));assert.equal(profiles.length,1);assert.equal(profiles[0].type,'oauth-token');assert(profiles[0].refreshToken===undefined,'Access-only profile required; values suppressed')
 inst=await startProxyServer({host:'127.0.0.1',port:PORT,profiles,defaultProfile:profiles[0].id})
 // Actual caller-owned tool loop: echo the precise returned call IDs and append results.
 const messages=[{role:'system',content:prefix('keyed')},{role:'user',content:`Read ${Object.keys(files).join(', ')} in order. Call read once at a time, waiting for its result before the next call. After all three results, answer briefly without additional calls.`}],delivered=[]
 let previous,answered=false
 for(let turn=0;turn<5;turn++){
  const {message,row}=await post('keyed-tool-'+turn,messages,{'x-session-id':key},tools)
  if(turn>0){assert.equal(row.lineage,'continuation');const read=row.usage?.prompt_tokens_details?.cached_tokens??0;assert(read>=.95*previous,'Lost prior cached prefix')}
  previous=(row.usage?.prompt_tokens_details?.cached_tokens??0)+(row.usage?.cache_write_tokens??row.usage?.prompt_tokens_details?.cache_write_tokens??0)
  assert(previous>0,'Cacheable prefix must actually be measured')
  messages.push(message);await snapshot(key)
  const calls=message.tool_calls??[]
  if(!calls.length){answered=true;break}
  assert.equal(calls.length,1,'Sequential fixture requires one call per turn');const call=calls[0];assert.equal(call.function.name,'read');const path=JSON.parse(call.function.arguments).file_path;assert(path in files,'Unowned tool path');assert(!delivered.includes(call.id));delivered.push(call.id);messages.push({role:'tool',tool_call_id:call.id,content:files[path]})
 }
 assert(answered&&delivered.length===3,'Tool loop failed to complete all three actual calls')
 const prior=await snapshot(key);messages.push({role:'user',content:'Reply briefly without tools.'});const follow=await post('keyed-follow-up',messages,{'x-session-id':key},tools);assert.equal(follow.row.lineage,'continuation');assert((follow.row.usage?.prompt_tokens_details?.cached_tokens??0)>=.95*previous);const active=await snapshot(key);assert.notEqual(active.source.claudeSessionId,prior.source.claudeSessionId)
 const blocks=active.rows.flatMap(row=>Array.isArray(row.message?.content)?row.message.content:[])
 for(const id of delivered){const results=blocks.filter(block=>block.type==='tool_result'&&block.tool_use_id===id);assert.equal(results.length,1);assert(!results[0].is_error)}
 for(const {source,SHA256}of sourceHashes.values())assert.equal(digest(await history(source)),SHA256,'Fork mutated source history')
 report.toolResultsExactlyOnce=true;report.unchangedSources=sourceHashes.size
 // A distinct explicit key must not inherit the completed conversation.
 const isolated=await post('distinct-chat',[{role:'system',content:prefix('distinct')},{role:'user',content:'Reply briefly without tools.'}],{'x-session-id':'other-'+nonce});assert.equal(isolated.row.lineage,'new');const other=await snapshot('other-'+nonce);assert.notEqual(other.source.claudeSessionId,active.source.claudeSessionId);report.distinctChat=true
 // Ordinary headerless requests continue packing; no derived tool key exists.
 const plain=[{role:'system',content:prefix('packed')},{role:'user',content:'Reply briefly without tools.'}]
 const first=await post('headerless-first',plain);plain.push(first.message,{role:'user',content:'Reply briefly again without tools.'});const second=await post('headerless-second',plain)
 assert.equal(first.row.lineage,'new');assert.equal(second.row.lineage,'new');assert.equal(second.row.usage?.prompt_tokens_details?.cached_tokens??0,0);report.headerlessPacked=true
 report.result='PASS'
}catch(error){report.result='FAIL';report.failure=error?.message??error?.name}
finally{
 try{await inst?.close()}catch(error){report.result='FAIL';report.closeFailure=error.name}
 report.children=[];for(const actor of actors)report.children.push(await stopAndJoinChild(actor.child,actor.witness));report.joined=report.children.every(row=>row.joined);if(!report.joined)report.result='FAIL'
 await observer.close();for(const spy of spies.reverse())spy.mockRestore();writeFileSync(join(WORK,'openai-report.json'),JSON.stringify(report,null,2)+'\n',{mode:0o600});say(JSON.stringify({root:WORK,result:report.result,joined:report.joined,failure:report.failure}));process.exitCode=report.result==='PASS'?0:1
}
