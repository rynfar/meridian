// Read only the owned public bookkeeping database; SDK history uses getSessionMessages.
import {Database}from'bun:sqlite';import{join}from'node:path';import{existsSync}from'node:fs';
let directory;export function setSessionStoreDir(value){directory=value;process.env.MERIDIAN_SESSION_DIR=value}
export function readSessionStoreSnapshot(){const path=join(directory,'session-bookkeeping.sqlite');if(!existsSync(path))return{};const db=new Database(path,{readonly:true});try{return Object.fromEntries(db.query('SELECT key,claude_session_id,current_locator_json FROM mappings').all().map(row=>[row.key,{claudeSessionId:row.claude_session_id,...(row.current_locator_json?{currentTranscript:JSON.parse(row.current_locator_json)}:{})}]))}finally{db.close()}}
