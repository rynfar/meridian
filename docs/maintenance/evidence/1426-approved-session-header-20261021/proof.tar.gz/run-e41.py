from pathlib import Path
import subprocess,json,os,time,socket,hashlib,shutil,signal
root=Path('/private/tmp/meridian-1426-approved-20261021');out=Path('/tmp/meridian-approved-actions-20261021');bun='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin/bun';hold=Path('/tmp/meridian-resume-20261020/LIVE_MODEL_HOLD.json');hold_sha=hashlib.sha256(hold.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
record={'head':head,'scope':'Four original E41 modes, SDK0.2.141/native2.1.306, Sonnet5.5, Macarm64, installed V1 client hook and scrub0.2.3; protocol host rather than OpenCode executable','cases':[],'result':'RUNNING'}
def save():(out/'1426-e41.json').write_text(json.dumps(record,indent=2)+'\n')
try:
 for mode in ['chain-json','chain-stream','parallel-json','parallel-stream']:
  assert hashlib.sha256(hold.read_bytes()).hexdigest()==hold_sha
  target=out/('e41-'+mode);assert not target.exists();target.mkdir()
  for d in ['home','native-config']:(target/d).mkdir(mode=0o700)
  subprocess.run([bun,str(out/'prepare-live-grant.mjs')],cwd=root,check=True)
  admission=json.loads((out/'1426-live-admission.json').read_text())
  sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close()
  env={k:v for k,v in os.environ.items()if k in ['PATH','LANG','LC_ALL','TERM','TMPDIR']}
  env.update(BOOKKEEPING_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib',HOME=str(target/'home'),CLAUDE_CONFIG_DIR=str(target/'native-config'),MERIDIAN_CLAUDE_PATH=admission['native']['path'],MERIDIAN_CREDENTIALS_READONLY='1',MERIDIAN_NO_UPDATE_CHECK='1',E2E_MERIDIAN_ROOT=str(root),E2E_MODEL_WITNESS=str(target/'model-witness.json'),E2E_ALLOW_LIVE_MODEL='1',E2E_LIVE_PROFILE_FILE=str(out/'private/access-only.json'),E2E_USAGE_GUARD_FILE=str(out/'1426-live-admission.json'),E2E_PLUGIN_PATH=str(out/'opencode-scrub-0.2.3/package/dist/index.js'),E2E_SCRUB_VERSION='0.2.3',E2E_CLIENT_PLUGIN_PATH=str(root/'dist/meridian/index.js'),E2E_CLIENT_VERSION='1.85.0',PROBE_MODEL='claude-sonnet-5-5',PROBE_PARALLEL='1'if mode.startswith('parallel')else'0',PROBE_TURNS='6',PROBE_PORT=str(port))
  row={'mode':mode,'admission':admission};record['cases'].append(row);save()
  with(target/'run.log').open('w')as log:
   process=subprocess.Popen([bun,'--preload',str(root/'src/__tests__/fixtures/bookkeeping-engine-preload.mjs'),str(out/'qualified-e41/run-e41.mjs')]+(['--stream']if mode.endswith('stream')else[]),cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['controllerPID']=process.pid;save()
   try:code=process.wait(timeout=240)
   except subprocess.TimeoutExpired:
    row['timeout']=True;os.killpg(process.pid,signal.SIGTERM)
    try:code=process.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=10)
  lines=(target/'run.log').read_text().splitlines();result=next((json.loads(line)for line in reversed(lines)if line.startswith('{"root":')),None);report={}
  if result:report=json.loads((Path(result['root'])/'qualified-e41-report.json').read_text());(target/'report.json').write_text(json.dumps(report,indent=2)+'\n')
  witness=json.loads((target/'model-witness.json').read_text())if(target/'model-witness.json').exists()else{}
  identities=[]
  for provider in witness.get('provider',[]):
   for event in provider.get('events',[]):
    if event.get('type')!='message_start':continue
    query=provider['query'];model=event.get('model');identities.append({'query':query,'providerID':event.get('id'),'model':model,'status':provider.get('status'),'child':any(c['query']==query and c.get('closed')for c in witness['children']),'nativeInit':any(n['query']==query and n.get('type')=='init'and n.get('model','').replace('[1m]','')==model for n in witness['native']),'nativeMessage':any(n['query']==query and n.get('id')==event.get('id')and n.get('model')==model for n in witness['native']),'publicStored':any(n.get('id')==event.get('id')and n.get('model')==model for store in witness['stored']for n in store['rows'])})
  (target/'identity-correlation.json').write_text(json.dumps(identities,indent=2)+'\n')
  generations=witness.get('generationCount',0);correlated=len(identities)==generations>0 and all(x['model']=='claude-sonnet-5-5'and x['status']==200 and x['child']and x['nativeInit']and x['nativeMessage']and x['publicStored']for x in identities)
  row.update(exit=code,result=result,assertions=report.get('result'),generations=generations,realForwards=witness.get('realForwards',0),joined=report.get('joined'),correlated=correlated,stopped=witness.get('stopped'))
  row['nativeUnchanged']=hashlib.sha256(Path(admission['native']['path']).read_bytes()).hexdigest()==admission['native']['SHA256']
  row['qualified']=row['nativeUnchanged']and code==0 and report.get('result')=='PASS'and row['joined']and correlated and witness.get('closed')and not witness.get('stopped')and 0<generations<=12 and row['realForwards']==generations and all(report.get('cacheClear',{}).get(k)is True for k in ['completionPromise','durableMappingsCleared','freshSession','originalHistoryUnchanged'])
  save();print(json.dumps({k:v for k,v in row.items()if k!='admission'}),flush=True)
  assert row['qualified'],'Preserve exact failure; no model/account retry or further cases'
  fixture=Path(result['root']);assert fixture.name.startswith('meridian-probe-proxy-')and not fixture.is_symlink();shutil.rmtree(fixture)
  for d in ['home','native-config']:shutil.rmtree(target/d)
  row['fixtureRemoved']=True;save()
 record['result']='PASS'
finally:
 record['olderHoldsUnchanged']=hashlib.sha256(hold.read_bytes()).hexdigest()==hold_sha
 if record['result']!='PASS':record['result']='FAIL'
 save();print(json.dumps({'result':record['result'],'cases':len(record['cases'])}),flush=True)
