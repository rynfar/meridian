import assert from 'node:assert/strict'
import {readFileSync,writeFileSync,existsSync,statSync,realpathSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {pathToFileURL} from 'node:url'
const root='/private/tmp/meridian-1426-approved-20261021',out='/tmp/meridian-approved-actions-20261021'
const {resolveOpenCodeClient,loadOpenCodeClient}=await import(pathToFileURL(root+'/scripts/lib-opencode-client-preflight.mjs'))
const {resolveOpenCodeScrub}=await import(pathToFileURL(root+'/scripts/lib-opencode-scrub-preflight.mjs'))
const client=await loadOpenCodeClient(resolveOpenCodeClient(root+'/dist/meridian/index.js','1.85.0'),'1426-credentialless-preflight')
const scrub=resolveOpenCodeScrub(out+'/opencode-scrub-0.2.3/package/dist/index.js','0.2.3')
assert(client.report.preflight)
const native=realpathSync('/Users/rynfar/.local/bin/claude')
const nativeSHA256=createHash('sha256').update(readFileSync(native)).digest('hex')
process.env.MERIDIAN_CREDENTIALS_READONLY='1'
const {loadProfilesFromDisk}=await import(pathToFileURL(root+'/src/proxy/profiles.ts'))
const {createPlatformCredentialStore}=await import(pathToFileURL(root+'/src/proxy/tokenRefresh.ts'))
const profile=loadProfilesFromDisk()[1];assert(profile?.claudeConfigDir)
const oauth=(await createPlatformCredentialStore({claudeConfigDir:profile.claudeConfigDir}).read())?.claudeAiOauth
assert(oauth?.accessToken&&oauth.expiresAt>Date.now()+300000,'No token refresh permitted')
const headers={Authorization:'Bearer '+oauth.accessToken,'anthropic-beta':'oauth-2025-04-20',Accept:'application/json'}
const response=await fetch('https://api.anthropic.com/api/oauth/profile',{headers,redirect:'error',signal:AbortSignal.timeout(10000)})
assert.equal(response.status,200);const meta=await response.json()
assert(['active','trialing'].includes(meta.organization?.subscription_status));assert.equal(meta.organization?.has_extra_usage_enabled,false)
const identity=createHash('sha256').update(meta.account?.uuid??'missing').digest('hex')
const known=JSON.parse(readFileSync('/tmp/meridian-resume-20261020/private/1397-independent-profile-metadata.json'))
assert.equal(identity,known.rows.find(row=>row.ordinal===1).accountIdentitySHA256)
const observationPath=out+'/1426-capacity.json'
let capacity
if(existsSync(observationPath))capacity=JSON.parse(readFileSync(observationPath))
else {
 const usage=await fetch('https://api.anthropic.com/api/oauth/usage',{headers,redirect:'error',signal:AbortSignal.timeout(10000)})
 capacity={at:new Date().toISOString(),HTTP:usage.status,retries:0,modelCalls:0,accountIdentitySHA256:identity,windows:[]}
 if(usage.ok){const data=await usage.json();capacity.windows=['five_hour','seven_day'].filter(key=>data[key]).map(type=>({type,utilization:data[type].utilization/100,resetsAt:data[type].resets_at}))}
 writeFileSync(observationPath,JSON.stringify(capacity,null,2)+'\n')
}
assert.equal(capacity.accountIdentitySHA256,identity)
assert(!capacity.windows.some(row=>row.utilization>=1),'Known exhausted capacity: stop without inference')
const canInfer=capacity.windows.length===2&&capacity.windows.every(row=>row.utilization>=0&&row.utilization<1)&&Date.now()-Date.parse(capacity.at)<300000
const grant=out+'/private/access-only.json',grants=[{id:'pool-a',type:'oauth-token',oauthToken:oauth.accessToken}]
assert.equal(statSync(out+'/private').mode&0o077,0)
if(existsSync(grant))assert(JSON.stringify(JSON.parse(readFileSync(grant)))===JSON.stringify(grants),'No token or account switching; secret values suppressed')
else writeFileSync(grant,JSON.stringify(grants),{mode:0o600,flag:'wx'})
const guard={at:new Date().toISOString(),task:'1426-owner-approved-session-header',canInfer,windows:canInfer?capacity.windows:[],extraUsageEnabled:false,organizationPlanActive:true,profileExtraUsageEnabled:false,includedAttemptPermitted:true,includedCapacityKnown:canInfer,maximumGenerationsPerCase:12,maximumCases:7,distinctAccounts:1,refreshes:0,credentialWrites:0,profileHTTP:response.status,accountIdentitySHA256:identity,native:{path:native,SHA256:nativeSHA256,version:'2.1.306'},client:client.report,scrub,authorizationBasis:'Owner-approved generic OpenAI identity verification, four E41 modes plus two affected OpenAI modes and the original E58 control. Separate never-attempted task; older held failures preserved. Included capacity only, no refresh, account/model fallback, paid usage or retry after a provider/model refusal.'}
writeFileSync(out+'/1426-live-admission.json',JSON.stringify(guard,null,2)+'\n')
console.log(JSON.stringify({preflight:true,profileHTTP:200,canInfer,capacityHTTP:capacity.HTTP,paidExtraUsage:false,native:guard.native,maximumCases:7,maximumGenerationsPerCase:12}))
