from pathlib import Path
import subprocess,os,json,hashlib,time,re
root=Path('/private/tmp/meridian-1426-approved-20261021');out=Path('/tmp/meridian-approved-actions-20261021');tar=Path('/tmp/meridian-release-20261019/registry-1.84.0.tgz');SHA256='0bc7e56683ec375bf4aba02c09f2275db1e5310dcc05bf5274b528335fc2ed3d'
assert hashlib.sha256(tar.read_bytes()).hexdigest()==SHA256
assert json.loads((out/'1426-live.json').read_text())['result']=='PASS'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();env=dict(os.environ,MERIDIAN_TEST_SQLITE_LIBRARY='/opt/homebrew/opt/sqlite/lib/libsqlite3.dylib',BOOKKEEPING_COMPAT_TARBALL=str(tar));env['PATH']='/tmp/meridian-resume-20261020/1219-native-engine-r2/runtime/package/bin'+os.pathsep+env['PATH'];start=time.monotonic()
with(out/'1426-compat.log').open('w')as log:result=subprocess.run(['bun','test','--timeout','30000','--test-name-pattern','^compat ','src/__tests__/bookkeeping-old-artifacts.test.ts'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
text=(out/'1426-compat.log').read_text();record={'head':head,'tarSHA256':SHA256,'exit':result.returncode,'seconds':time.monotonic()-start,'pass':sum(map(int,re.findall(r'^\s*(\d+) pass\s*$',text,re.M))),'skip':sum(map(int,re.findall(r'^\s*(\d+) skip\s*$',text,re.M))),'fail':sum(map(int,re.findall(r'^\s*(\d+) fail\s*$',text,re.M)))}
record['qualified']=record['exit']==0 and record['pass']==27 and record['skip']==0 and record['fail']==0;(out/'1426-compat.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);assert record['qualified']
