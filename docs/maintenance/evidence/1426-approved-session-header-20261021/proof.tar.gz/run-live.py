from pathlib import Path
import subprocess,json,hashlib
out=Path('/tmp/meridian-approved-actions-20261021');root=Path('/private/tmp/meridian-1426-approved-20261021');plan=json.loads((out/'1426-live-plan.json').read_text());local=json.loads((out/'1426-final-local.json').read_text())
assert local['head']==plan['head'] and len(local['commands'])==3 and all(row['exit']==0 for row in local['commands'])
def check():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==plan['head']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
 for name,SHA256 in plan['scripts'].items():
  p=out/name if (out/name).exists() else out/'qualified-e41'/name
  assert hashlib.sha256(p.read_bytes()).hexdigest()==SHA256,name
record={'head':plan['head'],'phases':[],'result':'RUNNING'}
def save():(out/'1426-live.json').write_text(json.dumps(record,indent=2)+'\n')
try:
 for phase in ['e41','openai']:
  check();print('Starting '+phase+' on '+plan['head'],flush=True)
  result=subprocess.run(['python3',str(out/('run-'+phase+'.py'))],cwd=root)
  record['phases'].append({'name':phase,'exit':result.returncode});save();assert result.returncode==0,'Retain original failure; no further models'
  check()
 record['result']='PASS'
finally:
 (out/'private/access-only.json').unlink(missing_ok=True);record['grantRemoved']=not (out/'private/access-only.json').exists()
 if record['result']!='PASS':record['result']='FAIL'
 save();print(json.dumps(record),flush=True)
