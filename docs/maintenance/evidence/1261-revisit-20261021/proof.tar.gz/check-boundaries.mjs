import assert from 'node:assert/strict'
import {mkdirSync,writeFileSync} from 'node:fs'
import {join} from 'node:path'
const root='/tmp/meridian-1261-revisit-20261021'
for(const name of ['home','config','profile'])mkdirSync(join(root,name),{recursive:true,mode:0o700})
Object.assign(process.env,{HOME:join(root,'home'),CLAUDE_CONFIG_DIR:join(root,'profile'),MERIDIAN_CONFIG_DIR:join(root,'config'),MERIDIAN_TRANSCRIPT_RETENTION_DAYS:'30'})
const {createTranscriptSweep}=await import('./transcriptSweep.ts')
const rows=[];const profile={configDir:join(root,'profile'),explicitConfigDir:true,profileIds:['owned-no-credential-fixture']}
for(const scenario of ['idle-control','busy-control','became-busy-during-credential-read']){
 let busy=scenario==='busy-control',started=0,released=0,admitRead,finishRead
 const readEntered=new Promise(resolve=>{admitRead=resolve}),credentials=new Promise(resolve=>{finishRead=resolve})
 const sweep=createTranscriptSweep({listRoots:()=>[profile],isRootBusy:()=>busy,isDraining:()=>false,credentialsReadOnly:()=>false,tryAcquireSlot:()=>({release(){released++}}),readCredentials:async()=>{admitRead();return credentials},runChild:async()=>{started++;return {refusedConnections:0,error:'No native process is created by this scheduler control'}},log:()=>{},pollMs:1})
 const running=sweep.runPass()
 if(scenario!=='busy-control'){await readEntered;if(scenario==='became-busy-during-credential-read')busy=true;finishRead({})}
 const result=await running;await sweep.stop();const expectedStarts=scenario==='idle-control'?1:0
 rows.push({scenario,started,released,expectedStarts,contractPass:started===expectedStarts,outcome:result[0]?.outcome.kind})
}
{
 let joined=false,released=0,finishChild
 const child=new Promise(resolve=>{finishChild=resolve}),hold=setInterval(()=>{},1000)
 const sweep=createTranscriptSweep({listRoots:()=>[profile],isRootBusy:()=>false,isDraining:()=>false,credentialsReadOnly:()=>false,tryAcquireSlot:()=>({release(){released++}}),readCredentials:async()=>({}),runChild:()=>child.finally(()=>{joined=true}),log:()=>{},childTimeoutMs:0,pollMs:1})
 try{const result=await sweep.runPass();rows.push({scenario:'timed-out-unjoined-child',outcome:result[0]?.outcome.kind,joinedWhenPassReturned:joined,releasedBeforeChildJoin:released>0&&!joined,contractPass:released===0||joined});finishChild({refusedConnections:0});await child;await Promise.resolve();await sweep.stop()}finally{clearInterval(hold)}
}
assert(rows[0].contractPass&&rows[1].contractPass)
assert(!rows[2].contractPass&&!rows[3].contractPass,'Both adverse schedules must demonstrate the current boundary defects')
const report={head:'ec2e235da954e04eb56a9d9fe4b07c0a11eef63d',scope:'Deterministic scheduler/dependency controls on unchanged function bodies from the contributor source object. No SDK query, native process, model, credential store or actual transcript deletion runs.',rows,findingsReproduced:2}
writeFileSync(join(root,'boundary-controls.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report))
