const port = Number(process.argv[2])
Bun.serve({ hostname: "127.0.0.1", port, async fetch(req) {
  const url = new URL(req.url)
  console.log(req.method, url.pathname)
  if (req.method === "GET" && url.pathname === "/v1/models") return fetch("http://127.0.0.1:3456/v1/models")
  return new Response(JSON.stringify({ type: "error", error: { type: "api_error", message: "stub refuses generation" } }), { status: 503 })
}})
