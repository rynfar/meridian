#!/bin/sh
exec node /Users/rynfar/.volta/tools/image/packages/@earendil-works/pi-coding-agent/lib/node_modules/@earendil-works/pi-coding-agent/dist/cli.js "$@"
