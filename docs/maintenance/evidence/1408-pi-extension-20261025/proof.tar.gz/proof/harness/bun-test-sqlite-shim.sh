#!/bin/sh
# Test-only shim: load Homebrew SQLite 3.53.4 (WAL-reset fix) for bun test.
if [ "$1" = "test" ]; then shift; exec "/Users/rynfar/.bun/bin/bun" test --preload /tmp/mw-tools/sqlite-preload.ts "$@"; fi
exec "/Users/rynfar/.bun/bin/bun" "$@"
