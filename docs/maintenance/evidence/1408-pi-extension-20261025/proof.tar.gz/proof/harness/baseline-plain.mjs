import { mkdtempSync, realpathSync } from "node:fs"
import { tmpdir } from "node:os"
import { join } from "node:path"
const [repo, agent] = process.argv.slice(2)
const root = realpathSync(mkdtempSync(join(tmpdir(), "meridian-plain-baseline-")))
for (const key of Object.keys(process.env)) if (key.startsWith("MERIDIAN_") || key.startsWith("CLAUDE_PROXY_")) delete process.env[key]
Object.assign(process.env, { MERIDIAN_CONFIG_DIR: join(root, "cfg"), MERIDIAN_SESSION_DIR: join(root, "sessions"), MERIDIAN_WORKDIR: root, MERIDIAN_TELEMETRY_PERSIST: "0" })
const { startProxyServer } = await import(join(repo, "src/proxy/server.ts"))
const instance = await startProxyServer({ port: 0, host: "127.0.0.1", silent: true })
const url = `http://127.0.0.1:${instance.server.address().port}`
const headers = { "content-type": "application/json", "x-api-key": "x", "anthropic-version": "2023-06-01", ...(agent ? { "x-meridian-agent": agent } : {}) }
const res = await fetch(`${url}/v1/messages`, { method: "POST", headers, body: JSON.stringify({ model: "claude-haiku-5-5", max_tokens: 20, messages: [{ role: "user", content: "Reply with the word OK and nothing else." }] }) })
console.log(JSON.stringify({ repo, agent: agent ?? "default", status: res.status, body: (await res.text()).slice(0, 300) }))
await instance.close()
