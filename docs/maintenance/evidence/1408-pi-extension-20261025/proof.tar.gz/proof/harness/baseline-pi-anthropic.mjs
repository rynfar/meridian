// Baseline: Pi's built-in anthropic provider pointed at an in-process Meridian
// (the pre-extension models.json path). Usage: bun baseline-pi-anthropic.mjs <repo> <pi>
import { mkdtempSync, mkdirSync, realpathSync, writeFileSync } from "node:fs"
import { tmpdir } from "node:os"
import { join } from "node:path"
const [repo, pi] = process.argv.slice(2)
const root = realpathSync(mkdtempSync(join(tmpdir(), "meridian-pi-baseline-")))
for (const key of Object.keys(process.env)) if (key.startsWith("MERIDIAN_") || key.startsWith("CLAUDE_PROXY_")) delete process.env[key]
Object.assign(process.env, { MERIDIAN_CONFIG_DIR: join(root, "cfg"), MERIDIAN_SESSION_DIR: join(root, "sessions"), MERIDIAN_WORKDIR: root, MERIDIAN_TELEMETRY_PERSIST: "0" })
const { startProxyServer } = await import(join(repo, "src/proxy/server.ts"))
const instance = await startProxyServer({ port: 0, host: "127.0.0.1", silent: true })
const url = `http://127.0.0.1:${instance.server.address().port}`
const agentDir = join(root, "agent"); mkdirSync(agentDir, { recursive: true })
writeFileSync(join(agentDir, "models.json"), JSON.stringify({ providers: { anthropic: { baseUrl: url, apiKey: "x", headers: { "x-meridian-agent": "pi" } } } }))
const env = { ...process.env, PI_CODING_AGENT_DIR: agentDir }
for (const k of Object.keys(env)) if (k.startsWith("ANTHROPIC_") || k.startsWith("MERIDIAN_")) delete env[k]
const child = Bun.spawn([pi, "-p", "Reply with the word OK and nothing else.", "--model", "anthropic/claude-haiku-5-5", "--tools", "", "--no-session"], { cwd: root, env, stdout: "pipe", stderr: "pipe", stdin: "ignore" })
const [code, out, err] = await Promise.all([child.exited, new Response(child.stdout).text(), new Response(child.stderr).text()])
console.log(JSON.stringify({ repo, path: "anthropic provider via models.json", code, stdout: out.trim().slice(0, 300), stderr: err.trim().slice(0, 400) }))
await instance.close()
