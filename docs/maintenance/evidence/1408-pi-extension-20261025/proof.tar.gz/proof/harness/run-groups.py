import json, subprocess, sys, os
repo = sys.argv[1]; out = sys.argv[2]
script = json.load(open(os.path.join(repo, 'package.json')))['scripts']['test']
env = dict(os.environ, PATH='/tmp/mw-tools/bin:' + os.environ['PATH'])
with open(out, 'w') as log:
    for i, cmd in enumerate(script.split(' && ')):
        log.write(f'\n#### GROUP {i}: {cmd[:120]}\n'); log.flush()
        rc = subprocess.run(cmd, shell=True, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
        log.write(f'#### GROUP {i} EXIT {rc}\n'); log.flush()
    log.write('#### ALL DONE\n')
