/**
 * A session store mutation is synchronous, so its whole cost is event-loop
 * lag for every request the proxy serves. On a long-lived store (tens of MB)
 * re-parsing and re-serializing the whole file per mutation froze the loop for
 * hundreds of milliseconds at a time.
 */

import { afterEach, beforeEach, describe, expect, it, spyOn } from "bun:test"
import * as filesystem from "node:fs"
import { randomUUID } from "node:crypto"
import {
  closeSync,
  fsyncSync,
  mkdtempSync,
  openSync,
  readFileSync,
  renameSync,
  rmSync,
  writeFileSync,
} from "node:fs"
import { tmpdir } from "node:os"
import { join } from "node:path"
import {
  attachSharedTranscriptLocator,
  lookupSharedSession,
  readSessionStoreSnapshot,
  setSessionStoreDir,
  storeSharedSession,
} from "/Users/rynfar/repos/meridian-review-evidence-20261006/pr1211-linux-x64-preparation-20261009-round1/context/baseline/src/proxy/sessionStore.ts"

let syncMs = 0
let syncCalls = 0
const delayCell = new Int32Array(new SharedArrayBuffer(4))
const originalSync = filesystem.fsyncSync
const syncObserver = spyOn(filesystem, "fsyncSync").mockImplementation((fd: number) => {
  const start = performance.now()
  try { Atomics.wait(delayCell, 0, 0, 5); return originalSync(fd) } finally { syncMs += performance.now() - start; syncCalls++ }
})
afterEach(() => { syncObserver.mockRestore() })
const META_KEY = "\u0000meridian-session-store"

function hash(): string {
  return randomUUID().replaceAll("-", "")
}

function fixtureEntry(messageCount: number, lastUsedAt: number) {
  const claudeSessionId = randomUUID()
  return {
    claudeSessionId,
    revision: 1,
    generationId: randomUUID(),
    createdAt: lastUsedAt,
    lastUsedAt,
    messageCount,
    lineageHash: hash(),
    messageHashes: Array.from({ length: messageCount }, hash),
    messageBlockHashes: Array.from({ length: messageCount }, (_, index) => index % 3 ? [hash()] : [hash(), hash()]),
    sdkMessageUuids: Array.from({ length: messageCount }, (_, index) => index === messageCount - 1 ? randomUUID() : null),
    currentTranscript: { sessionId: claudeSessionId, configDir: "/home/user/.claude", projectDir: "/home/user/.claude/projects/p" },
  }
}

/** Write a store document the way a foreign writer does: temp file, fsync, rename. */
function publishForeign(dir: string, document: Record<string, unknown>): string {
  const text = JSON.stringify(document)
  const temp = join(dir, `sessions.json.tmp-foreign-${randomUUID()}`)
  const fd = openSync(temp, "wx", 0o600)
  writeFileSync(fd, text)
  fsyncSync(fd)
  closeSync(fd)
  renameSync(temp, join(dir, "sessions.json"))
  return text
}

function buildFixture(dir: string, entries: number, messagesPerEntry: number): { keys: string[]; text: string } {
  const document: Record<string, unknown> = { [META_KEY]: { version: 1, slots: {} } }
  const keys: string[] = []
  for (let index = 0; index < entries; index++) {
    const key = `profile${index % 4}:ses_${hash()}`
    keys.push(key)
    document[key] = fixtureEntry(messagesPerEntry, Date.now() - index * 1_000)
  }
  return { keys, text: publishForeign(dir, document) }
}

/** Event-loop delay caused by a synchronous call: how late an immediately due timer fires. */
async function loopLagOf(work: () => unknown): Promise<number> {
  syncMs = 0
  syncCalls = 0
  const scheduledAt = performance.now()
  const fired = new Promise<number>((resolve) => setTimeout(() => resolve(performance.now()), 0))
  work()
  const workEnded = performance.now()
  const timerAt = await fired
  console.log("LOOP_SAMPLE", JSON.stringify({ syncMs, syncCalls, synchronousMs: workEnded - scheduledAt, timerTailMs: timerAt - workEnded, totalMs: timerAt - scheduledAt }))
  return timerAt - scheduledAt
}

function median(values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b)
  return sorted[Math.floor(sorted.length / 2)]!
}

describe("session store mutation cost on a large store", () => {
  let dir: string

  beforeEach(() => {
    dir = mkdtempSync(join(tmpdir(), "store-loop-lag-"))
    setSessionStoreDir(dir)
  })

  afterEach(() => {
    setSessionStoreDir(null)
    rmSync(dir, { recursive: true, force: true })
  })

  it("keeps a warm mutation's loop lag well below the full-document parse, serialize and write it replaced", async () => {
    const { keys, text } = buildFixture(dir, 400, 180)
    expect(text.length).toBeGreaterThan(5_000_000)

    // What every mutation used to do on the loop: parse, serialize, write, fsync.
    const baselines: number[] = []
    for (let run = 0; run < 3; run++) {
      baselines.push(await loopLagOf(() => {
        const parsed = JSON.parse(readFileSync(join(dir, "sessions.json"), "utf8"))
        const fd = openSync(join(dir, `baseline-${run}`), "w", 0o600)
        writeFileSync(fd, JSON.stringify(parsed))
        fsyncSync(fd)
        closeSync(fd)
      }))
    }

    // The first mutation after a foreign write parses once and encodes every entry once.
    storeSharedSession(keys[0]!, randomUUID(), 3, hash(), [hash(), hash(), hash()])
    const lags: number[] = []
    for (let index = 1; index <= 5; index++) {
      lags.push(await loopLagOf(() => {
        storeSharedSession(keys[index]!, randomUUID(), 3, hash(), [hash(), hash(), hash()])
      }))
    }
    const entry = lookupSharedSession(keys[6]!)!
    lags.push(await loopLagOf(() => {
      attachSharedTranscriptLocator(keys[6]!, entry.claudeSessionId, {
        sessionId: entry.claudeSessionId,
        configDir: "/home/user/.claude",
        projectDir: "/home/user/.claude/projects/other",
      })
    }))

    console.log(`[loop-lag] ${(text.length / 1e6).toFixed(1)} MB store: warm mutation median ${median(lags).toFixed(1)} ms, max ${Math.max(...lags).toFixed(1)} ms; full-document baseline median ${median(baselines).toFixed(1)} ms`)
    console.log("LOOP_PHASES", JSON.stringify({ baselines, lags }))
    expect(median(lags)).toBeLessThan(median(baselines) * 0.75)
  })

})
