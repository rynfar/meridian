// Actual local HTTP request, failing before provider/SDK invocation by design.
import assert from 'node:assert/strict'
import {mkdtempSync,mkdirSync,writeFileSync,readFileSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {join} from 'node:path'
import {pathToFileURL} from 'node:url'
import {createRequire} from 'node:module'
import {createHash} from 'node:crypto'
import {spyOn,mock} from 'bun:test'
import * as cp from 'node:child_process'
const ROOT=process.env.E2E_MERIDIAN_ROOT,OUTPUT=process.env.E2E_OUTPUT
assert(ROOT&&OUTPUT)
const root=mkdtempSync(join(tmpdir(),'meridian-1440-http-'))
for(const name of ['home','config','native','opencode'])mkdirSync(join(root,name),{mode:0o700})
for(const key of Object.keys(process.env))if(/^(MERIDIAN_|CLAUDE_PROXY_|CLAUDE_|ANTHROPIC_)/.test(key))delete process.env[key]
Object.assign(process.env,{HOME:join(root,'home'),CLAUDE_CONFIG_DIR:join(root,'native'),MERIDIAN_CONFIG_DIR:join(root,'config'),MERIDIAN_SESSION_DIR:join(root,'sessions'),MERIDIAN_WORKDIR:root,MERIDIAN_CREDENTIALS_READONLY:'1',MERIDIAN_NO_UPDATE_CHECK:'1',MERIDIAN_TELEMETRY_PERSIST:'0'})
const require=createRequire(ROOT+'/package.json'),sdkPath=require.resolve('@anthropic-ai/claude-agent-sdk'),sdk=await import(sdkPath)
let sdkQueries=0
mock.module(sdkPath,()=>({...sdk,query(){sdkQueries++;throw new Error('This pre-backend gate must never invoke the SDK')}}))
const {observeChildClosure,stopAndJoinChild}=await import(pathToFileURL(ROOT+'/scripts/lib/e2eProcessCustody.mjs'))
const actors=[],spies=[]
for(const name of ['spawn','execFile']){const original=cp[name];spies.push(spyOn(cp,name).mockImplementation((...args)=>{const child=Reflect.apply(original,cp,args);actors.push({child,witness:observeChildClosure(child)});return child}))}
const realFetch=globalThis.fetch,external=[]
globalThis.fetch=(input,init)=>{const url=new URL(input instanceof Request?input.url:String(input));if(['127.0.0.1','localhost'].includes(url.hostname))return realFetch(input,init);external.push({host:url.hostname,path:url.pathname});throw new Error('External traffic disabled in the pre-backend fault gate')}
const pool=join(root,'opencode/pool.json');writeFileSync(pool,JSON.stringify({version:3,activeIndex:0,accounts:[{accountId:'owned-fake-workspace',accountUserId:'owned-fake-user',email:'owned@example.test',refreshToken:'noncredential-refresh',accessToken:'noncredential-access',expiresAt:Date.now()+3600000,addedAt:1,lastUsed:1}]}),{mode:0o600})
process.env.MERIDIAN_CHATGPT_CREDENTIALS='follow-external';process.env.MERIDIAN_CODEX_POOL_PATH=pool
const pluginConfigPath=join(root,'plugins.json');writeFileSync(pluginConfigPath,JSON.stringify({plugins:[]}))
const {createProxyServer}=await import(pathToFileURL(ROOT+'/src/proxy/server.ts'))
const {processSessionTree}=await import(pathToFileURL(ROOT+'/src/proxy/sessionTree.ts'))
const {openCodeAdapter}=await import(pathToFileURL(ROOT+'/src/proxy/adapters/opencode.ts'))
const {serve}=await import(require.resolve('@hono/node-server'))
const report={root,scope:'Real HTTP500 before backend dispatch, synthetic follow-external credential file, all external traffic and SDK generations forbidden. No real ChatGPT provider success is claimed; the changed boundary precedes that provider.',serverSHA256:createHash('sha256').update(readFileSync(ROOT+'/src/proxy/server.ts')).digest('hex'),cases:[],result:'RUNNING'}
const save=()=>writeFileSync(OUTPUT,JSON.stringify(report,null,2)+'\n')
save()
let failed=false
try{
 for(const boundary of ['session-key','session-tree']){
  const proxy=createProxyServer({host:'127.0.0.1',port:0,silent:true,profiles:[{id:'no-provider',type:'api-key',apiKey:'owned-noncredential'}],defaultProfile:'no-provider',pluginDir:join(root,'no-plugins'),pluginConfigPath})
  assert(proxy.getInFlightCount&&proxy.closeBackend&&proxy.forceAbortInFlight)
  await proxy.initPlugins?.()
  const fault=()=>{throw new Error('owned setup failure')}
  const failure=boundary==='session-key'?spyOn(openCodeAdapter,'getSessionId').mockImplementation(fault):spyOn(processSessionTree,'register').mockImplementation(fault)
  const listeners=[];let listening
  const ready=new Promise(resolve=>{listening=resolve})
  const server=serve({hostname:'127.0.0.1',port:0,overrideGlobalObjects:false,fetch(request,...rest){if(new URL(request.url).pathname==='/v1/responses'){const add=spyOn(request.signal,'addEventListener'),remove=spyOn(request.signal,'removeEventListener');listeners.push({add,remove})}return proxy.app.fetch(request,...rest)}},info=>listening(info.port))
  const port=await ready,row={boundary,externalBefore:external.length};report.cases.push(row);save()
  try{
   const response=await fetch(`http://127.0.0.1:${port}/v1/responses`,{method:'POST',headers:{'content-type':'application/json','x-meridian-agent':'opencode'},body:JSON.stringify({model:'gpt-6-luna',stream:true,prompt_cache_key:'owned-conversation',input:[{role:'user',content:'owned failure probe'}]}),signal:AbortSignal.timeout(10000)})
   await response.text();row.HTTP=response.status;assert.equal(row.HTTP,500);assert.equal(failure.mock.calls.length,1)
   const inflight=await(await fetch(`http://127.0.0.1:${port}/inflight`)).json();row.total=inflight.total;row.admitted=proxy.getInFlightCount();row.chatgpt=inflight.upstreams.chatgpt
   const tracked=listeners[0];row.listenersAdded=tracked.add.mock.calls.length;row.listenersRemoved=tracked.remove.mock.calls.length;row.exactListenerRemoved=tracked.add.mock.calls.every(([type,listener])=>tracked.remove.mock.calls.some(([removedType,removedListener])=>removedType===type&&removedListener===listener))
   row.backendRequests=external.slice(row.externalBefore).filter(item=>item.host==='chatgpt.com'&&item.path==='/backend-api/codex/responses').length
   row.qualified=row.total===0&&row.admitted===0&&row.listenersAdded>0&&row.exactListenerRemoved&&row.backendRequests===0&&sdkQueries===0
   if(!row.qualified)failed=true
   save()
  }finally{
   failure.mockRestore();for(const tracked of listeners){tracked.add.mockRestore();tracked.remove.mockRestore()}
   proxy.forceAbortInFlight();server.closeAllConnections?.();await new Promise((resolve,reject)=>server.close(error=>error?reject(error):resolve()))
   let joined=false;const cleanup=proxy.closeBackend().then(()=>{joined=true})
   if(row.admitted===0)await cleanup
   else await new Promise(resolve=>setTimeout(resolve,20))
   // The unchanged baseline's leaked count keeps shutdown waiting forever.
   // Preserve that failed join, then end this owned process after actor custody.
   row.backendOwnerJoined=joined;row.transportClosed=!server.listening;save()
  }
 }
 report.result=failed?'FAIL':'PASS'
}catch(error){report.result='FAIL';report.failure=error?.message??error?.name}
finally{
 report.children=[];for(const actor of actors)report.children.push(await stopAndJoinChild(actor.child,actor.witness));report.joined=report.children.every(row=>row.joined);report.sdkQueries=sdkQueries;report.backendRequests=external.filter(item=>item.host==='chatgpt.com'&&item.path==='/backend-api/codex/responses').length;report.externalFetchForwarded=0;report.realCredentialsProvided=false
 if(!report.joined)report.result='FAIL';globalThis.fetch=realFetch;for(const spy of spies.reverse())spy.mockRestore();save();console.log(JSON.stringify(report));process.exit(report.result==='PASS'?0:1)
}
